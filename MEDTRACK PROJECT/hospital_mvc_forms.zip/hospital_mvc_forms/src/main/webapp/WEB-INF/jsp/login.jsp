<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Galaxy Hospital Login</title>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
/* ===== GENERAL PAGE ===== */
body {
    margin: 0;
    padding: 0;
    font-family: "Poppins", sans-serif;
    background: linear-gradient(135deg, #a8c0ff, #3f2b96);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
}

/* ===== CONTAINER ===== */
.container {
    background: #ffffff;
    border-radius: 25px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
    width: 400px;
    padding: 50px 40px;
    text-align: center;
    animation: fadeIn 1s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-25px); }
    to { opacity: 1; transform: translateY(0); }
}

h1 {
    color: #2C3E50;
    font-size: 28px;
    margin-bottom: 8px;
}

.subtitle {
    color: #6C757D;
    font-size: 15px;
    margin-bottom: 25px;
}

/* ===== ERROR MESSAGE ===== */
.error-msg {
    color: #d62828;
    background: #ffeaea;
    border-left: 5px solid #d62828;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-weight: 600;
}

/* ===== INPUT FIELDS ===== */
.form-group {
    position: relative;
    margin-bottom: 18px;
}

.form-group i {
    position: absolute;
    top: 14px;
    left: 15px;
    color: #888;
}

input, select {
    width: 100%;
    padding: 12px 15px 12px 40px;
    border-radius: 10px;
    border: 1px solid #ccc;
    font-size: 15px;
    transition: all 0.3s ease;
    box-sizing: border-box;
}

input:focus, select:focus {
    border-color: #3f2b96;
    box-shadow: 0 0 5px #3f2b96;
    outline: none;
}

/* ===== BUTTON ===== */
button {
    width: 100%;
    background: linear-gradient(135deg, #5563DE, #3849B1);
    border: none;
    border-radius: 10px;
    color: white;
    font-size: 16px;
    font-weight: 600;
    padding: 12px;
    cursor: pointer;
    transition: all 0.3s ease;
}

button:hover {
    background: linear-gradient(135deg, #3849B1, #27338C);
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(56, 73, 177, 0.3);
}

/* ===== FOOTER ===== */
.footer {
    margin-top: 20px;
    font-size: 13px;
    color: #555;
}

.footer a {
    color: #3849B1;
    text-decoration: none;
    font-weight: 600;
}

.footer a:hover {
    text-decoration: underline;
}

/* ===== DOCTOR ILLUSTRATION ===== */
.bg-doctor {
    position: absolute;
    bottom: 0;
    right: 30px;
    width: 420px;
    opacity: 0.15;
    z-index: 0;
    animation: float 4s ease-in-out infinite;
}

@keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0px); }
}

@media (max-width: 480px) {
    .container {
        width: 90%;
        padding: 30px;
    }
    .bg-doctor { display: none; }
}
</style>
</head>

<body>
    <!-- Floating background doctor -->
    <img src="https://cdn-icons-png.flaticon.com/512/4481/4481219.png" alt="Doctor illustration" class="bg-doctor">

    <div class="container">
        <h1><i class="fa-solid fa-hospital"></i> Galaxy Hospital</h1>
        <p class="subtitle">Please log in to continue</p>

        <% 
            String errorMsg = (String) request.getAttribute("errorMsg");
            if (errorMsg != null) {
        %>
            <div class="error-msg"><i class="fa-solid fa-triangle-exclamation"></i> <%= errorMsg %></div>
        <% } %>

        <form action="loginLogic">
            <div class="form-group">
                <i class="fa-solid fa-user"></i>
                <input type="text" name="username" placeholder="Enter Username" required>
            </div>

            <div class="form-group">
                <i class="fa-solid fa-lock"></i>
                <input type="password" name="password" placeholder="Enter Password" required>
            </div>

            <div class="form-group">
                <i class="fa-solid fa-user-shield"></i>
                <select name="role" required>
                    <option value="">Select Role</option>
                    <option value="doctor">👨‍⚕️ Doctor</option>
                    <option value="patient">🧑‍⚕️ Patient</option>
                    <option value="admin">🏥 Admin</option>
                </select>
            </div>

            <button type="submit"><i class="fa-solid fa-right-to-bracket"></i> Login</button>
        </form>

        <div class="footer">
            <p>Need help? <a href="#">Contact Support</a></p>
        </div>
    </div>
</body>
</html>
