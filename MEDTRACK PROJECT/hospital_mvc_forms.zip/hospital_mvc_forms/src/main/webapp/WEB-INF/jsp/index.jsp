<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Galaxy Hospital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #e0f7fa, #f1f9ff, #ffffff);
            color: #2C3E50;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            overflow: hidden;
        }

        .container {
            background: #ffffff;
            border: none;
            padding: 70px 100px;
            border-radius: 25px;
            box-shadow: 0 10px 30px rgba(0, 131, 176, 0.25);
            max-width: 650px;
            animation: fadeIn 1s ease;
            position: relative;
        }

        h1 {
            font-size: 38px;
            margin-bottom: 15px;
            color: #0083b0;
            letter-spacing: 1px;
        }

        p {
            font-size: 18px;
            margin-bottom: 35px;
            color: #555;
        }

        a.button {
            text-decoration: none;
            background: linear-gradient(90deg, #0083b0, #00b4db);
            color: white;
            padding: 14px 40px;
            border-radius: 30px;
            font-weight: 600;
            transition: all 0.4s ease;
            box-shadow: 0 5px 15px rgba(0,131,176,0.4);
        }

        a.button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,180,219,0.5);
        }

        footer {
            position: absolute;
            bottom: 15px;
            font-size: 14px;
            color: #666;
            width: 100%;
            text-align: center;
            letter-spacing: 0.5px;
        }

        .hospital-icon {
            font-size: 65px;
            color: #00b4db;
            margin-bottom: 25px;
            animation: pulse 2s infinite;
        }

        /* Soft floating medical symbols in the background */
        .bg-shape {
            position: absolute;
            border-radius: 50%;
            opacity: 0.15;
            background: #00b4db;
            animation: float 6s ease-in-out infinite;
        }
        .shape1 { width: 150px; height: 150px; top: 10%; left: 5%; }
        .shape2 { width: 100px; height: 100px; bottom: 15%; right: 10%; animation-delay: 2s; }
        .shape3 { width: 80px; height: 80px; top: 60%; left: 20%; background: #0083b0; animation-delay: 4s; }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }

        @keyframes pulse {
            0% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.1); opacity: 0.8; }
            100% { transform: scale(1); opacity: 1; }
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
    </style>

    <!-- Font Awesome for hospital icon -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>

<body>
    <!-- Decorative floating shapes -->
    <div class="bg-shape shape1"></div>
    <div class="bg-shape shape2"></div>
    <div class="bg-shape shape3"></div>

    <div class="container">
        <i class="fas fa-hospital hospital-icon"></i>
        <h1>Welcome to Galaxy Hospital</h1>
        <p>Your health, our priority — experience excellence in care.</p>
        <a href="${pageContext.request.contextPath}/login" class="button">Click here to Login</a>
    </div>

    <footer>
        © 2025 Galaxy Hospital. All rights reserved.
    </footer>
</body>
</html>
