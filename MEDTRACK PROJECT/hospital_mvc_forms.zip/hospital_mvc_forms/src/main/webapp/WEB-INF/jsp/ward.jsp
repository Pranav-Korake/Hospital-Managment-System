<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard - Manage Beds</title>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
/* ====== General Layout ====== */
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #e0f7fa, #f8f9fa);
    margin: 0;
    padding: 40px;
    color: #2C3E50;
    min-height: 100vh;
}

/* ====== Title ====== */
h2 {
    text-align: center;
    font-size: 30px;
    color: #0077b6;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 1px;
    position: relative;
    animation: fadeInDown 1s ease;
}

h2::after {
    content: "";
    display: block;
    width: 100px;
    height: 4px;
    background-color: #00b4db;
    margin: 10px auto;
    border-radius: 10px;
}

/* ====== Ward Section ====== */
.ward {
    background: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    margin: 25px auto;
    width: 80%;
    transition: all 0.3s ease;
    animation: fadeInUp 0.6s ease;
}

.ward:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,131,176,0.25);
}

.ward-name {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 15px;
    color: #0083b0;
}

/* ====== Bed Grid ====== */
.beds {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(60px, 1fr));
    gap: 12px;
}

.bed {
    width: 60px;
    height: 60px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 3px 10px rgba(0,0,0,0.15);
    position: relative;
    overflow: hidden;
}

/* Animated glow effect */
.bed::after {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(rgba(255,255,255,0.2), transparent 70%);
    opacity: 0;
    transition: opacity 0.3s;
}

.bed:hover::after {
    opacity: 1;
}

.bed:hover {
    transform: scale(1.1);
}

/* ====== Bed Status Colors ====== */
.allocated {
    background: linear-gradient(145deg, #e63946, #b71c1c);
}

.empty {
    background: linear-gradient(145deg, #43a047, #2e7d32);
}

.maintenance {
    background: linear-gradient(145deg, #fdd835, #fbc02d);
    color: #2C3E50;
}

/* ====== Popup Styling ====== */
.popup {
    display: none;
    position: fixed;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%) scale(0.8);
    background: #ffffff;
    border: none;
    padding: 25px 35px;
    z-index: 1000;
    border-radius: 15px;
    box-shadow: 0 6px 25px rgba(0,0,0,0.3);
    width: 300px;
    text-align: center;
    transition: all 0.3s ease;
    animation: popupFade 0.4s ease forwards;
}

.popup h3 {
    color: #0077b6;
    font-size: 20px;
    margin-bottom: 15px;
}

.popup button {
    margin: 8px;
    padding: 10px 18px;
    border: none;
    border-radius: 25px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    color: white;
}

.popup button:nth-child(2) { background-color: #0083b0; }
.popup button:nth-child(3) { background-color: #43a047; }
.popup button:nth-child(4) { background-color: #fbc02d; color: #2C3E50; }
.popup button:hover { transform: scale(1.05); }

.overlay {
    display: none;
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 500;
}

/* ====== Animations ====== */
@keyframes fadeInDown {
    0% { opacity: 0; transform: translateY(-30px); }
    100% { opacity: 1; transform: translateY(0); }
}

@keyframes fadeInUp {
    0% { opacity: 0; transform: translateY(30px); }
    100% { opacity: 1; transform: translateY(0); }
}

@keyframes popupFade {
    from { transform: translate(-50%, -50%) scale(0.7); opacity: 0; }
    to { transform: translate(-50%, -50%) scale(1); opacity: 1; }
}

/* ====== Legend ====== */
.legend {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 15px;
    font-size: 14px;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 6px;
}

.legend-square {
    width: 18px; height: 18px; border-radius: 4px;
}
.legend-allocated { background-color: #e63946; }
.legend-empty { background-color: #43a047; }
.legend-maintenance { background-color: #fdd835; }
</style>
</head>

<body>
<h2>Admin Dashboard - Manage Beds</h2>

<!-- Legend -->
<div class="legend">
    <div class="legend-item"><div class="legend-square legend-allocated"></div>Allocated</div>
    <div class="legend-item"><div class="legend-square legend-empty"></div>Empty</div>
    <div class="legend-item"><div class="legend-square legend-maintenance"></div>Maintenance</div>
</div>

<div id="wardsContainer"></div>

<!-- Overlay -->
<div class="overlay" id="overlay" onclick="closePopup()"></div>

<!-- Popup -->
<div class="popup" id="popup">
    <h3 id="popupBedTitle">Update Bed Status</h3>
    <button onclick="updateBedStatus('ALLOCATED')"><i class="fa-solid fa-bed"></i> Allocate</button>
    <button onclick="updateBedStatus('EMPTY')"><i class="fa-solid fa-circle-check"></i> Deallocate</button>
    <button onclick="updateBedStatus('MAINTENANCE')"><i class="fa-solid fa-screwdriver-wrench"></i> Maintenance</button>
    <button onclick="closePopup()" style="background:#d9534f;"><i class="fa-solid fa-xmark"></i> Close</button>
</div>

<!-- Script (Unchanged Backend Logic) -->
<script>
const API_URL = "http://localhost:7171/beds/";
let currentBed = null;

async function loadBeds() {
    try {
        const response = await fetch(API_URL);
        if(!response.ok) throw new Error("Failed to fetch beds");
        const beds = await response.json();

        const wards = {};
        beds.forEach(b => {
            if(!wards[b.wardName]) wards[b.wardName] = [];
            wards[b.wardName].push(b);
        });

        const container = document.getElementById('wardsContainer');
        container.innerHTML = '';

        for(const [wardName, wardBeds] of Object.entries(wards)){
            const wardDiv = document.createElement('div'); wardDiv.className='ward';
            const wardTitle = document.createElement('div'); wardTitle.className='ward-name'; wardTitle.innerText = wardName;
            const bedsDiv = document.createElement('div'); bedsDiv.className='beds';

            wardBeds.sort((a,b)=>a.bedNo-b.bedNo).forEach(bed=>{
                const bedDiv = document.createElement('div'); 
                bedDiv.innerHTML = `<i class='fa-solid fa-bed'></i><br>${bed.bedNo}`;
                bedDiv.className = 'bed ' + bed.status.toLowerCase();
                bedDiv.onclick = ()=> openBedPopup(bed);
                bedsDiv.appendChild(bedDiv);
            });

            wardDiv.appendChild(wardTitle);
            wardDiv.appendChild(bedsDiv);
            container.appendChild(wardDiv);
        }

    } catch(err){
        console.error(err);
        document.getElementById('wardsContainer').innerText = "Error loading beds. Check API URL and CORS.";
    }
}

function openBedPopup(bed){
    currentBed = bed;
    document.getElementById('popupBedTitle').innerText = `${bed.wardName} - Bed ${bed.bedNo} (${bed.status})`;
    document.getElementById('popup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closePopup(){
    document.getElementById('popup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

async function updateBedStatus(status){
    if(!currentBed) return;

    try{
        const response = await fetch(API_URL,{
            method:'PUT',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({
                id: currentBed.id,
                wardName: currentBed.wardName,
                bedNo: currentBed.bedNo,
                status: status
            })
        });
        if(!response.ok) throw new Error("Failed to update bed");

        const bedsDivs = document.querySelectorAll('.bed');
        bedsDivs.forEach(div=>{
            const wardDiv = div.parentElement.previousElementSibling.innerText;
            if(div.innerText.includes(currentBed.bedNo) && wardDiv == currentBed.wardName){
                div.className = 'bed ' + status.toLowerCase();
            }
        });

        currentBed.status = status;
        closePopup();
    }catch(err){
        console.error(err);
        alert("Error updating bed status");
    }
}

window.onload = loadBeds;
</script>
</body>
</html>
