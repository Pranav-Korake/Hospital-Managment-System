<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Employee Registration Form</h2>
    <form action="add-employee" method="post" >

        <!-- Employee ID -->
        <div class="mb-3">
            <label for="employeeId" class="form-label">Employee ID</label>
            <input type="text" class="form-control" id="employeeId" name="employeeId" required>
        </div>

        <!-- Full Name -->
        <div class="mb-3">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>

        <!-- Gender -->
        <div class="mb-3">
            <label class="form-label">Gender</label><br>
            <input type="radio" name="gender" value="Male" required> Male
            <input type="radio" name="gender" value="Female"> Female
            <input type="radio" name="gender" value="Other"> Other
        </div>

        <!-- Date of Birth -->
        <div class="mb-3">
            <label for="dateOfBirth" class="form-label">Date of Birth</label>
            <input type="date" class="form-control" id="dateOfBirth" name="dateOfBirth" required>
        </div>

        <!-- Contact Number -->
        <div class="mb-3">
            <label for="contactNumber" class="form-label">Contact Number</label>
            <input type="text" class="form-control" id="contactNumber" name="contactNumber" required>
        </div>

        <!-- Email -->
        <div class="mb-3">
            <label for="email" class="form-label">Email ID</label>
            <input type="text" class="form-control" id="email" name="email">
        </div>

        <!-- Address -->
        <div class="mb-3">
            <label for="address" class="form-label">Address</label>
            <textarea class="form-control" id="address" name="address" rows="3"></textarea>
        </div>

        <!-- Role -->
        <div class="mb-3">
            <label for="role" class="form-label">Role</label>
            <input type="text" class="form-control" id="role" name="role">
        </div>

        <!-- Joining Date -->
        <div class="mb-3">
            <label for="joiningDate" class="form-label">Joining Date</label>
            <input type="date" class="form-control" id="joiningDate" name="joiningDate">
        </div>

        <!-- Salary -->
        <div class="mb-3">
            <label for="salary" class="form-label">Salary</label>
            <input type="text" class="form-control" id="salary" name="salary">
        </div>

        <!-- Shift -->
        <div class="mb-3">
            <label for="shift" class="form-label">Shift</label>
            <input type="text" class="form-control" id="shift" name="shift">
        </div>

        <!-- Status -->
        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <input type="text" class="form-control" id="status" name="status">
        </div>

        <!-- Employee Photo -->
        <div class="mb-3">
            <label for="emp_photo_url" class="form-label">Upload Employee Photo</label>
            <input type="text" class="form-control" id="emp_photo_url" name="emp_photo_url">
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Register Employee</button>
    </form>
</div>
</body>
</html>
