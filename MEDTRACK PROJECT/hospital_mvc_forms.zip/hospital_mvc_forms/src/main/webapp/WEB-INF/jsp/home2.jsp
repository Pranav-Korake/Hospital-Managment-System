<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h3 style="color:green">PATIENT CRUD</h3>

<a href="add-patient-form">ADD PATIENT</a><br></br>
<a href="update-patient-form">UPDATE PATIENT</a><br></br>
<a href="delete-patient-form">DELETE PATIENT</a><br></br>
<a href="selectById-patient-form">SELECT PATIENT BY ID</a><br></br>
<a href="selectByName-patient-form">SELECT PATIENT BY NAME</a><br></br>
<a href="selectAll-patient">SELECT ALL PATIENT</a><br></br>
<a href="deleteAll-patient">DELETE ALL PATIENT </a><br></br>

<h3 style="color:green">DOCTOR CRUD</h3>
<a href="add-doctor-form">ADD DOCTOR</a><br></br>
<a href="update-doctor-form">UPDATE DOCTOR</a><br></br>
<a href="delete-doctor-form">DELETE DOCTOR</a><br></br>


<a href="selectById-doctor-form">SELECT DOCTOR</a><br></br>
<a href="selectAll-doctor">SELECT ALL DOCTORS</a><br></br>
<a href="deleteAll-doctor">DELETE ALL DOCTORS</a><br></br>






<a href="selectByName-doctor-form">SELECT BY NAME DOCTOR</a><br></br>

<a href="selectByQualification-doctor-form">SELECT BY QUALIFICATION DOCTOR</a><br></br>


<a href="selectBySpecialization-doctor-form">SELECT BY SPECIALIZATION DOCTOR</a><br></br>


<a href="selectByExperience-doctor-form">SELECT BY EXPERIENCE DOCTOR</a>


</body>
</html>