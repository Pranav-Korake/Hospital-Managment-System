<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Delete Doctor</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f0f2f5;
        }
        .card {
            border-radius: 20px;
            box-shadow: 0px 4px 20px rgba(0,0,0,0.1);
        }
        .card-header {
            border-radius: 20px 20px 0 0;
            background: linear-gradient(45deg, #4e73df, #1cc88a);
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .form-control {
            border-radius: 12px;
        }
        .btn-danger {
            border-radius: 12px;
            padding: 10px 30px;
            font-weight: bold;
        }
        .btn-danger:hover {
            background-color: #e74a3b;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center">
                    Delete Doctor
                </div>
                <div class="card-body">
                    <form action="delete-doctor" method="post" >
                        
                        <!-- Doctor ID -->
                        <div class="mb-3">
                            <label class="form-label">Doctor ID</label>
                            <input type="number" class="form-control" name="doctorId" placeholder="Enter Doctor ID" required>
                        </div>
                        
                        <!-- Submit -->
                        <div class="text-center">
                            <button type="submit" class="btn btn-danger">Delete Doctor</button>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
