<button id="bookAppointmentBtn">Book Appointment</button>

<!-- Old Patient Search Section -->
<div id="oldPatientSearch" style="display:none; margin-top: 10px;">
    <h3>Search Old Patient by Phone Number</h3>
    <input type="text" id="oldPatientPhone" placeholder="Enter phone number">
    <button id="searchBtn">Search</button>
    <div id="patientList" style="margin-top:10px;"></div>
</div>

<!-- Optional: New Patient Form -->
<div id="newPatientForm" style="display:none; margin-top: 10px;">
    <h3>New Patient Registration</h3>
    <input type="text" id="newPatientName" placeholder="Patient Name"><br>
    <input type="text" id="newPatientPhone" placeholder="Phone Number"><br>
    <button id="registerPatientBtn">Register & Book Appointment</button>
</div>

<script>
document.getElementById('bookAppointmentBtn').addEventListener('click', function() {
    const patientType = prompt("Is the patient New or Old? (Enter 'new' or 'old')");
    if(patientType === null) return;

    if(patientType.toLowerCase() === 'old') {
        document.getElementById('oldPatientSearch').style.display = 'block';
        document.getElementById('newPatientForm').style.display = 'none';
    } 
    else if(patientType.toLowerCase() === 'new') {
        document.getElementById('newPatientForm').style.display = 'block';
        document.getElementById('oldPatientSearch').style.display = 'none';
    } 
    else {
        alert("Invalid input! Please enter 'new' or 'old'.");
    }
});

// AJAX search for old patients
document.getElementById('searchBtn').addEventListener('click', function() {
    const phone = document.getElementById('oldPatientPhone').value.trim();
    const resultsDiv = document.getElementById('patientList');
    resultsDiv.innerHTML = "Searching...";

    // Create AJAX request
    const xhr = new XMLHttpRequest();
    xhr.open("GET", `/search-patient?phone=${encodeURIComponent(phone)}`, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    
    xhr.onreadystatechange = function() {
        if(xhr.readyState === 4) {
            if(xhr.status === 200) {
                const data = JSON.parse(xhr.responseText);
                resultsDiv.innerHTML = "";
                if(data.length === 0) {
                    resultsDiv.innerHTML = "No patients found with this phone number.";
                    return;
                }
                data.forEach(p => {
                    const div = document.createElement('div');
                    div.innerHTML = `${p.name} (ID: ${p.id}) <button onclick="bookAppointment(${p.id})">Book Appointment</button>`;
                    resultsDiv.appendChild(div);
                });
            } else {
                resultsDiv.innerHTML = "Error fetching patient data.";
            }
        }
    };
    xhr.send();
});

// Function to handle booking for selected patient
function bookAppointment(patientId) {
    alert(`Booking appointment for patient ID: ${patientId}`);
    // Show appointment form or redirect to appointment page here
}
</script>
