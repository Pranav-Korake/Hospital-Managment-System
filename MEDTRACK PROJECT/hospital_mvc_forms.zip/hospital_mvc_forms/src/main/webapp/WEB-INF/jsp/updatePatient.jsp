<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Patient Update</title>
    <!-- Optional: Bootstrap for styling -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Patient Updation Form</h2>
    <form action="update-patient" method="post" >
        
        <!-- Patient ID -->
        <div class="mb-3">
            <label for="patientId" class="form-label">Patient ID</label>
            <input type="text" class="form-control" id="patientId" name="patientId" required>
        </div>

        <!-- Name -->
        <div class="mb-3">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>

        <!-- Gender -->
        <div class="mb-3">
            <label class="form-label">Gender</label><br>
            <input type="radio" name="gender" value="Male"> Male
            <input type="radio" name="gender" value="Female"> Female
            <input type="radio" name="gender" value="Other"> Other
        </div>

        <!-- Date of Birth -->
        <div class="mb-3">
            <label for="dateOfBirth" class="form-label">Date of Birth</label>
            <input type="date" class="form-control" id="dateOfBirth" name="dateOfBirth" required>
        </div>

        <!-- Contact Number -->
        <div class="mb-3">
            <label for="contactNumber" class="form-label">Contact Number</label>
            <input type="text" class="form-control" id="contactNumber" name="contactNumber" required>
        </div>

        <!-- Email -->
        <div class="mb-3">
            <label for="email" class="form-label">Email ID</label>
            <input type="text" class="form-control" id="email" name="email">
        </div>

        <!-- Address -->
        <div class="mb-3">
            <label for="address" class="form-label">Address</label>
            <textarea class="form-control" id="address" name="address" rows="3"></textarea>
        </div>

        <!-- Blood Group -->
        <div class="mb-3">
            <label for="bloodGroup" class="form-label">Blood Group</label>
            <select class="form-select" id="bloodGroup" name="bloodGroup">
                <option value="">--Select--</option>
                <option>A+</option>
                <option>A-</option>
                <option>B+</option>
                <option>B-</option>
                <option>O+</option>
                <option>O-</option>
                <option>AB+</option>
                <option>AB-</option>
            </select>
        </div>

        <!-- Age -->
        <div class="mb-3">
            <label for="age" class="form-label">Age</label>
            <input type="text" class="form-control" id="age" name="age" required>
        </div>

        <!-- Weight -->
        <div class="mb-3">
            <label for="weight" class="form-label">Weight (kg)</label>
            <input type="text" class="form-control" id="weight" name="weight">
        </div>

        <!-- Emergency Contact Name -->
        <div class="mb-3">
            <label for="emergencyContactName" class="form-label">Emergency Contact Name</label>
            <input type="text" class="form-control" id="emergencyContactName" name="emergencyContactName">
        </div>

        <!-- Emergency Contact Number -->
        <div class="mb-3">
            <label for="emergencyContactNumber" class="form-label">Emergency Contact Number</label>
            <input type="text" class="form-control" id="emergencyContactNumber" name="emergencyContactNumber">
        </div>

        <!-- Patient Photo -->
        <div class="mb-3">
            <label for="patient_photo_url" class="form-label">Upload Patient Photo</label>
            <input type="text" class="form-control" id="patient_photo_url" name="patient_photo_url" ">
        </div>

        <!-- Submit -->
        <button type="submit" class="btn btn-primary">Update Patient</button>
    </form>
</div>
</body>
</html>
