<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Book Appointment</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<body>
<div class="container mt-5">
<h2>Book Appointment</h2>

<form action="add-appointment" method="post">
    <input type="hidden" name="patientId" value="${appointment.patient.patientId}" />

    <!-- Patient Name -->
    <div class="form-group">
        <label>Patient Name</label>
        <input type="text" class="form-control" name="patientName" value="${appointment.patientName}" readonly />
    </div>

    <!-- Doctor Dropdown -->
    <div class="form-group">
        <label>Select Doctor</label>
        <select class="form-control" id="doctor" name="doctorId" required>
            <option value="">-- Select Doctor --</option>
            <c:forEach var="doc" items="${doctorList}">
                <option value="${doc.doctorId}" data-fee="${doc.consultationFee}">
                    ${doc.name} (${doc.specialization})
                </option>
            </c:forEach>
        </select>
    </div>

    <!-- Doctor Name & Fee -->
    <div class="form-group">
        <label>Doctor Name</label>
        <input type="text" class="form-control" id="doctorName" name="doctorName" readonly />
    </div>
    <div class="form-group">
        <label>Amount</label>
        <input type="text" class="form-control" id="amount" name="amount" readonly />
    </div>

    <!-- Date & Time -->
    <div class="form-group">
        <label>Date</label>
        <input type="date" class="form-control" name="date" required />
    </div>
    <div class="form-group">
        <label>Time Slot</label>
        <input type="time" class="form-control" name="timeSlot" required />
    </div>

    <!-- Payment Mode -->
    <div class="form-group">
        <label>Payment Mode</label>
        <select class="form-control" name="paymentMode" required>
            <option value="">-- Select Payment Mode --</option>
            <option value="Cash">Cash</option>
            <option value="Card">Card</option>
            <option value="UPI">UPI</option>
            <option value="Online Banking">Online Banking</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Book Appointment</button>
</form>
</div>

<script>
$('#doctor').change(function() {
    var selectedDoctor = $(this).find('option:selected');
    var doctorName = selectedDoctor.text().split(' (')[0];
    var fee = selectedDoctor.data('fee');

    $('#doctorName').val(doctorName);
    $('#amount').val(fee);
});
</script>
</body>
</html>
