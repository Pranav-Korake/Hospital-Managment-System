<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Prescription</title>
    <link rel="stylesheet" 
          href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2>Add Prescription for ${appointment.patientName}</h2>
    <form action="save-prescription" method="post">
        <input type="hidden" name="appointmentId" value="${appointment.appointmentId}" />

        <div class="form-group">
            <label>Patient Name:</label>
            <input type="text" class="form-control" value="${appointment.patientName}" disabled>
        </div>

        <div class="form-group">
            <label>Date:</label>
            <input type="text" class="form-control" value="${appointment.date}" disabled>
        </div>

        <div class="form-group">
            <label>Time Slot:</label>
            <input type="text" class="form-control" value="${appointment.timeSlot}" disabled>
        </div>

        <div class="form-group">
            <label>Prescription:</label>
            <textarea class="form-control" name="prescription" rows="5" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Save Prescription</button>
    </form>
</div>
</body>
</html>
