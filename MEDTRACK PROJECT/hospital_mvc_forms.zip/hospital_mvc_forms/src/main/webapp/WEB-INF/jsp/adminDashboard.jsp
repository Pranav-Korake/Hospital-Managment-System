<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Dashboard - Galaxy Hospital</title>

<!-- Bootstrap 4 CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- Animate.css for animations -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

<!-- Lottie animation -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lottie-web/5.10.0/lottie.min.js"></script>

<style>
body {
    font-family: "Poppins", sans-serif;
    background: linear-gradient(135deg, #e0f7fa, #f8f9fa);
    overflow-x: hidden;
    min-height: 100vh;
}

.navbar {
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    background: linear-gradient(90deg, #0077b6, #00b4d8);
}

.navbar-brand {
    font-weight: bold;
    font-size: 1.4rem;
}

.navbar-brand i {
    color: #fff;
    margin-right: 8px;
}

.nav-link {
    color: #fff !important;
    transition: all 0.3s ease;
}

.nav-link:hover {
    color: #d4f1f9 !important;
    transform: translateY(-2px);
}

.dropdown-menu {
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
}

.container {
    margin-top: 80px;
    text-align: center;
    position: relative;
}

.welcome-msg {
    margin-bottom: 30px;
    font-size: 28px;
    font-weight: 600;
    color: #2C3E50;
    animation: fadeInDown 1s ease;
}

/* Animated admin illustration */
#adminAnimation {
    width: 220px;
    height: 220px;
    margin: 0 auto 20px auto;
    animation: float 3s ease-in-out infinite;
}

/* Floating animation */
@keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0px); }
}

/* Ward Button */
.btn-ward {
    display: inline-block;
    padding: 15px 45px;
    font-size: 18px;
    font-weight: 600;
    border-radius: 30px;
    color: white;
    background: linear-gradient(90deg, #0083b0, #00b4db);
    transition: all 0.4s ease;
    margin-top: 25px;
    text-decoration: none;
    box-shadow: 0 4px 10px rgba(0,131,176,0.3);
}

.btn-ward:hover {
    background: linear-gradient(90deg, #00b4db, #0083b0);
    transform: scale(1.05);
    box-shadow: 0 6px 15px rgba(0,180,219,0.5);
    color: white;
}

/* Subtle background hospital overlay */
.background-icons {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    opacity: 0.07;
    z-index: -1;
}

.background-icons i {
    position: absolute;
    font-size: 80px;
    color: #0077b6;
    animation: moveIcons 15s linear infinite;
}

@keyframes moveIcons {
    from { transform: translateY(100vh) rotate(0deg); }
    to { transform: translateY(-10vh) rotate(360deg); }
}
</style>
</head>

<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><i class="fa-solid fa-hospital"></i> Galaxy Hospital</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse"
            data-target="#navbarNavDropdown">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">

                <!-- Doctor Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="doctorDropdown" data-toggle="dropdown">
                        <i class="fa-solid fa-user-doctor"></i> Doctor
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="add-doctor-form"><i class="fa-solid fa-user-plus"></i> Add Doctor</a>
                        <a class="dropdown-item" href="update-doctor-form"><i class="fa-solid fa-pen"></i> Update Doctor</a>
                        <a class="dropdown-item" href="delete-doctor-form"><i class="fa-solid fa-trash"></i> Delete Doctor</a>
                        <a class="dropdown-item" href="selectById-doctor-form"><i class="fa-solid fa-id-card"></i> Search by ID</a>
                        <a class="dropdown-item" href="selectByName-doctor-form"><i class="fa-solid fa-search"></i> Search by Name</a>
                        <a class="dropdown-item" href="selectByQualification-doctor-form"><i class="fa-solid fa-graduation-cap"></i> Search by Qualification</a>
                        <a class="dropdown-item" href="selectBySpecialization-doctor-form"><i class="fa-solid fa-stethoscope"></i> Search by Specialization</a>
                        <a class="dropdown-item" href="selectByExperience-doctor-form"><i class="fa-solid fa-briefcase"></i> Search by Experience</a>
                        <a class="dropdown-item" href="selectAll-doctor"><i class="fa-solid fa-list"></i> View All Doctors</a>
                        <a class="dropdown-item" href="deleteAll-doctor"><i class="fa-solid fa-trash-can"></i> Delete All Doctors</a>
                    </div>
                </li>

                <!-- Patient Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="patientDropdown" data-toggle="dropdown">
                        <i class="fa-solid fa-user"></i> Patient
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="add-patient-form"><i class="fa-solid fa-user-plus"></i> Add Patient</a>
                        <a class="dropdown-item" href="update-patient-form"><i class="fa-solid fa-pen"></i> Update Patient</a>
                        <a class="dropdown-item" href="delete-patient-form"><i class="fa-solid fa-trash"></i> Delete Patient</a>
                        <a class="dropdown-item" href="selectById-patient-form"><i class="fa-solid fa-id-card"></i> Search by ID</a>
                        <a class="dropdown-item" href="selectByName-patient-form"><i class="fa-solid fa-search"></i> Search by Name</a>
                        <a class="dropdown-item" href="selectAll-patient"><i class="fa-solid fa-users"></i> View All Patients</a>
                        <a class="dropdown-item" href="deleteAll-patient"><i class="fa-solid fa-user-slash"></i> Delete All Patients</a>
                        <a class="dropdown-item" href="bmi_calculator"><i class="fa-solid fa-weight-scale"></i> BMI Calculator</a>
                    </div>
                </li>

                <!-- Employee Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="employeeDropdown" data-toggle="dropdown">
                        <i class="fa-solid fa-users"></i> Employee
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="add-employee-form"><i class="fa-solid fa-user-plus"></i> Add Employee</a>
                        <a class="dropdown-item" href="update-employee-form"><i class="fa-solid fa-pen"></i> Update Employee</a>
                        <a class="dropdown-item" href="delete-employee-form"><i class="fa-solid fa-trash"></i> Delete Employee</a>
                        <a class="dropdown-item" href="selectById-employee-form"><i class="fa-solid fa-id-card"></i> Search by ID</a>
                        <a class="dropdown-item" href="selectByName-employee-form"><i class="fa-solid fa-search"></i> Search by Name</a>
                        <a class="dropdown-item" href="selectByRole-employee-form"><i class="fa-solid fa-briefcase"></i> Search by Role</a>
                        <a class="dropdown-item" href="selectByShiftAndRole-employee-form"><i class="fa-solid fa-clock"></i> Search by Shift & Role</a>
                        <a class="dropdown-item" href="selectAll-employee"><i class="fa-solid fa-list"></i> View All Employees</a>
                        <a class="dropdown-item" href="deleteAll-employee"><i class="fa-solid fa-trash-can"></i> Delete All Employees</a>
                    </div>
                </li>

                <!-- Logout -->
                <li class="nav-item">
                    <a class="nav-link" href="logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
                </li>

            </ul>
        </div>
    </div>
</nav>

<!-- Floating hospital icons background -->
<div class="background-icons">
    <i class="fa-solid fa-syringe" style="left:10%; animation-delay:0s;"></i>
    <i class="fa-solid fa-heartbeat" style="left:30%; animation-delay:3s;"></i>
    <i class="fa-solid fa-stethoscope" style="left:60%; animation-delay:6s;"></i>
    <i class="fa-solid fa-user-nurse" style="left:80%; animation-delay:9s;"></i>
</div>

<!-- Main Content -->
<div class="container">
    <div id="adminAnimation"></div>
    <div class="welcome-msg animate__animated animate__fadeInUp">
        Welcome Admin to your Dashboard
    </div>

    <!-- Manage Ward Button -->
    <a href="ward" class="btn-ward animate__animated animate__pulse animate__infinite">
        <i class="fa-solid fa-hospital"></i> Manage Ward
    </a>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Load Lottie Animation -->
<script>
var animation = lottie.loadAnimation({
    container: document.getElementById('adminAnimation'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: 'https://assets1.lottiefiles.com/packages/lf20_pprxh53t.json' // Doctor/admin animation
});
</script>

</body>
</html>
