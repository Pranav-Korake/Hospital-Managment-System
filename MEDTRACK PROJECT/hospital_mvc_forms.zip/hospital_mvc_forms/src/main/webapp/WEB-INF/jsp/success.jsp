<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Success Page</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0fdf4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .success-container {
            background-color: #e6f9ed;
            border: 1px solid #a3e4b0;
            padding: 40px 60px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            text-align: center;
        }

        .success-container h3 {
            color: #28a745;
            font-size: 24px;
            margin: 0;
        }

        .success-container p {
            color: #555;
            font-size: 16px;
            margin-top: 10px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 25px;
            color: #fff;
            background-color: #28a745;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #1e7e34;
        }
    </style>
</head>
<body>
    <div class="success-container">
        <h3>${msg}</h3>
        <p>Your operation was successful!</p>
        <a class="back-btn" href="javascript:history.back()">Go Back</a>
    </div>
</body>
</html>
