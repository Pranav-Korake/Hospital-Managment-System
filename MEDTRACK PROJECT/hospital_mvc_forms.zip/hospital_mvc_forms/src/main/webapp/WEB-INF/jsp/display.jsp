<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor Details - Galaxy Hospital</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(to right, #dceefc, #f0f4f8);
      padding: 30px 0;
    }

    .container {
      background-color: #fff;
      padding: 25px 20px;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
      animation: fadeIn 0.8s ease-in-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    h2 {
      text-align: center;
      color: #2C3E50;
      margin-bottom: 25px;
      font-weight: 600;
    }

    table {
      border-radius: 10px;
      overflow: hidden;
      width: 100%;
    }

    thead {
      background-color: #2C3E50;
      color: white;
      text-transform: uppercase;
      font-size: 13px;
    }

    tbody tr:nth-child(odd) {
      background-color: #f8f9fa;
    }

    tbody tr:hover {
      background-color: #e0f0ff;
      transform: scale(1.01);
      transition: all 0.3s ease;
    }

    td, th {
      text-align: center;
      vertical-align: middle !important;
      padding: 10px 5px;
    }

    .badge-available {
      background-color: #28a745;
      color: white;
      padding: 5px 10px;
      border-radius: 12px;
      font-size: 12px;
    }

    .badge-unavailable {
      background-color: #dc3545;
      color: white;
      padding: 5px 10px;
      border-radius: 12px;
      font-size: 12px;
    }

    .img-thumbnail {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      object-fit: cover;
      transition: transform 0.3s ease;
    }

    .img-thumbnail:hover {
      transform: scale(1.3);
    }
  </style>
</head>
<body>

<div class="container">
  <h2><i class="fa-solid fa-user-doctor"></i> Doctor Details</h2>

  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
        <tr>
          <th>Doctor ID</th>
          <th>Doctor Name</th>
          <th>Gender</th>
          <th>Date of birth</th>
          <th>Contact Number</th>
          <th>Email</th>
          <th>Qualification</th>
          <th>Specialization</th>
          <th>Experience</th>
          <th>License Number</th>
          <th>Consultation Fee</th>
          <th>Working Hours</th>
          <th>Availability Status</th>
          <th>Joining Date</th>
          <th>Address</th>
          <th>Photo</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>${d.doctorId}</td>
          <td>${d.name}</td>
          <td>${d.gender}</td>
          <td>${d.dateOfBirth}</td>
          <td>${d.contactNumber}</td>
          <td>${d.email}</td>
          <td>${d.qualification}</td>
          <td>${d.specialization}</td>
          <td>${d.experience}</td>
          <td>${d.licenseNumber}</td>
          <td>${d.consultationFee}</td>
          <td>${d.workingHours}</td>
          <td>
            <c:choose>
              <c:when test="${d.availabilityStatus eq 'Available'}">
                <span class="badge-available">Available</span>
              </c:when>
              <c:otherwise>
                <span class="badge-unavailable">Unavailable</span>
              </c:otherwise>
            </c:choose>
          </td>
          <td>${d.joiningDate}</td>
          <td>${d.address}</td>
          <td>
            <c:choose>
              <c:when test="${not empty d.photo_url}">
                <img src="${d.photo_url}" class="img-thumbnail" alt="Doctor Photo">
              </c:when>
              <c:otherwise>
                <i class="fa-solid fa-user-circle fa-2x text-muted"></i>
              </c:otherwise>
            </c:choose>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

</body>
</html>
