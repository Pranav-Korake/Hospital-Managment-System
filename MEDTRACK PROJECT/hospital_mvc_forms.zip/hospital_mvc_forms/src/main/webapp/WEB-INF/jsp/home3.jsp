<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h3 style="color:green">EMPLOYEE CRUD</h3>


<a href="add-employee-form">ADD EMPLOYEE</a><br></br>
<a href="update-employee-form">UPDATE EMPLOYEE</a><br></br>
<a href="delete-employee-form">DELETE EMPLOYEE</a><br></br>
<a href="selectById-employee-form">SELECT EMPLOYEE BY ID</a><br></br>
<a href="selectByName-employee-form">SELECT EMPLOYEE BY NAME</a><br></br>
<a href="selectByRole-employee-form">SELECT EMPLOYEE BY ROLE</a><br></br>
<!-- a href="selectByShiftAndRole-employee-form">SELECT EMPLOYEE BY SHIFT AND ROLE</a><br></br> -->
<a href="selectAll-employee">SELECT ALL EMPLOYEE</a><br></br>
<a href="deleteAll-Employee">DELETE ALL EMPLOYEE</a><br></br>


</body>
</html>