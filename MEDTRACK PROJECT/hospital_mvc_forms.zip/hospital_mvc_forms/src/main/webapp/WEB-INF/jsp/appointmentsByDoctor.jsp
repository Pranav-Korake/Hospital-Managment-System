<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Doctor Dashboard - Appointments</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet"
	href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
    font-family: "Poppins", sans-serif;
    background: linear-gradient(135deg, #a8c0ff, #3f2b96);
    min-height: 100vh;
    padding: 40px 0;
    color: #333;
}

.container {
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    padding: 30px 25px;
    animation: fadeIn 0.8s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}

h2 {
    text-align: center;
    color: #3f2b96;
    font-weight: 600;
    margin-bottom: 25px;
}

.table {
    border-radius: 10px;
    overflow: hidden;
}

.table thead {
    background: #3f2b96;
    color: #fff;
}

.table th {
    text-align: center;
    font-size: 15px;
    letter-spacing: 0.5px;
}

.table tbody tr {
    transition: all 0.3s ease;
}

.table tbody tr:hover {
    background: #f3f6ff;
    transform: scale(1.01);
}

.table td {
    text-align: center;
    vertical-align: middle !important;
    font-size: 14.5px;
}

/* Buttons & Links */
a {
    text-decoration: none;
}

.btn-custom {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 6px;
    font-weight: 600;
    font-size: 13px;
    transition: all 0.3s ease;
    color: #fff !important;
}

.btn-update {
    background: linear-gradient(135deg, #007bff, #0056b3);
}

.btn-update:hover {
    background: linear-gradient(135deg, #0056b3, #004094);
    transform: translateY(-1px);
}

.btn-prescription {
    background: linear-gradient(135deg, #28a745, #1e7e34);
}

.btn-prescription:hover {
    background: linear-gradient(135deg, #1e7e34, #155d27);
    transform: translateY(-1px);
}

/* Status Colors */
.status-pending {
    color: #ffc107;
    font-weight: 600;
}
.status-completed {
    color: #28a745;
    font-weight: 600;
}
.status-cancelled {
    color: #dc3545;
    font-weight: 600;
}
</style>
</head>

<body>

	<div class="container">
		<h2><i class="fa-solid fa-stethoscope"></i> Doctor Appointments</h2>

		<table class="table table-striped">
			<thead>
				<tr>
					<th><i class="fa-solid fa-user"></i> Patient Name</th>
					<th><i class="fa-solid fa-calendar-days"></i> Date</th>
					<th><i class="fa-solid fa-clock"></i> Time Slot</th>
					<th><i class="fa-solid fa-info-circle"></i> Status</th>
					<th><i class="fa-solid fa-pen-to-square"></i> Update Status</th>
					<th><i class="fa-solid fa-prescription-bottle-medical"></i> Add Prescription</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach items="${applist}" var="a">
					<tr>
						<td>${a.patientName}</td>
						<td>${a.date}</td>
						<td>${a.timeSlot}</td>
						<td>
							<span class="
								<c:choose>
									<c:when test='${a.status == "PENDING"}'>status-pending</c:when>
									<c:when test='${a.status == "COMPLETED"}'>status-completed</c:when>
									<c:otherwise>status-cancelled</c:otherwise>
								</c:choose>
							">
							${a.status}
							</span>
						</td>

						<td>
							<a href="update-appointment?appointmentId=${a.appointmentId}" class="btn-custom btn-update">
								<i class="fa-solid fa-pen"></i> Update
							</a>
						</td>

						<td>
							<a href="add-prescription?appointmentId=${a.appointmentId}" class="btn-custom btn-prescription">
								<i class="fa-solid fa-file-medical"></i> Add
							</a>
						</td>
					</tr>
				</c:forEach>
			</tbody>
		</table>
	</div>

</body>
</html>
