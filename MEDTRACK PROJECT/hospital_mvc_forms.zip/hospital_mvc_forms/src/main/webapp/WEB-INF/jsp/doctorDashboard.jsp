<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Doctor Dashboard - Galaxy Hospital</title>

<!-- Bootstrap 4 CSS -->
<link rel="stylesheet"
    href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<!-- Font Awesome for icons -->
<link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
body {
    font-family: "Poppins", sans-serif;
    background: linear-gradient(120deg, #e0f7fa, #ffffff, #f1f8ff);
    min-height: 100vh;
    overflow-x: hidden;
    animation: backgroundShift 8s ease-in-out infinite alternate;
}

/* Navbar */
.navbar {
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    animation: slideDown 0.8s ease;
}
.navbar-brand {
    font-weight: bold;
    font-size: 1.4rem;
}

/* Floating hospital icons */
.floating-icon {
    position: absolute;
    opacity: 0.1;
    animation: float 6s ease-in-out infinite;
}
.icon1 { top: 15%; left: 5%; font-size: 70px; color: #00b4db; animation-delay: 0s; }
.icon2 { bottom: 20%; right: 10%; font-size: 80px; color: #0083b0; animation-delay: 2s; }
.icon3 { top: 60%; right: 20%; font-size: 60px; color: #00799c; animation-delay: 4s; }

/* Doctor avatar */
.doctor-avatar {
    width: 180px;
    height: 180px;
    border-radius: 50%;
    background: linear-gradient(135deg, #00b4db, #0083b0);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 80px;
    margin: 30px auto;
    box-shadow: 0 8px 20px rgba(0,131,176,0.3);
    animation: pulseGlow 2s infinite ease-in-out;
    position: relative;
}

/* Doctor talking bubble */
.speech-bubble {
    position: absolute;
    top: -20px;
    left: 160px;
    background: #ffffff;
    color: #333;
    border-radius: 12px;
    padding: 12px 16px;
    font-weight: 500;
    font-size: 15px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    animation: fadeIn 1s ease;
}
.speech-bubble::after {
    content: "";
    position: absolute;
    left: -10px;
    top: 20px;
    border-width: 10px;
    border-style: solid;
    border-color: transparent #ffffff transparent transparent;
}

/* Main container */
.container {
    margin-top: 70px;
    text-align: center;
    animation: fadeInUp 1s ease;
}
.welcome-msg {
    font-size: 26px;
    font-weight: 600;
    color: #2C3E50;
    margin-bottom: 20px;
}

/* Button styles */
.btn-appointments {
    background: linear-gradient(90deg, #0083b0, #00b4db);
    color: white;
    padding: 14px 35px;
    border-radius: 30px;
    font-weight: 600;
    font-size: 16px;
    transition: all 0.3s ease;
    margin-top: 20px;
    box-shadow: 0 4px 10px rgba(0,131,176,0.3);
}
.btn-appointments:hover {
    background: linear-gradient(90deg, #00b4db, #0083b0);
    transform: translateY(-5px);
    box-shadow: 0 6px 18px rgba(0,180,219,0.4);
    text-decoration: none;
    color: white;
}

/* Form area */
form {
    margin-top: 30px;
    background: #ffffff;
    border-radius: 15px;
    padding: 25px 30px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    display: inline-block;
    animation: fadeIn 1.2s ease;
}
form input {
    border-radius: 8px;
}
form button {
    border-radius: 8px;
}

/* Animations */
@keyframes backgroundShift {
    0% { background: linear-gradient(120deg, #e0f7fa, #ffffff, #f1f8ff); }
    100% { background: linear-gradient(120deg, #ffffff, #e0f7fa, #dff9fb); }
}
@keyframes slideDown {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-15px); }
}
@keyframes pulseGlow {
    0%, 100% { box-shadow: 0 0 20px rgba(0,180,219,0.4); }
    50% { box-shadow: 0 0 40px rgba(0,180,219,0.7); }
}
</style>
</head>
<body>

<!-- Floating icons for background animation -->
<i class="fa-solid fa-stethoscope floating-icon icon1"></i>
<i class="fa-solid fa-syringe floating-icon icon2"></i>
<i class="fa-solid fa-user-doctor floating-icon icon3"></i>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><i class="fa-solid fa-hospital"></i> Galaxy Hospital</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse"
            data-target="#navbarNavDropdown">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">

                <!-- Patient Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="patientDropdown"
                       role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa-solid fa-user"></i> Patient
                    </a>
                    <div class="dropdown-menu" aria-labelledby="patientDropdown">
                        <a class="dropdown-item" href="add-patient-form"><i class="fa-solid fa-user-plus"></i> Add Patient</a>
                        <a class="dropdown-item" href="update-patient-form"><i class="fa-solid fa-pen"></i> Update Patient</a>
                        <a class="dropdown-item" href="delete-patient-form"><i class="fa-solid fa-trash"></i> Delete Patient</a>
                        <a class="dropdown-item" href="selectById-patient-form"><i class="fa-solid fa-id-card"></i> Search by ID</a>
                        <a class="dropdown-item" href="selectByName-patient-form"><i class="fa-solid fa-search"></i> Search by Name</a>
                        <a class="dropdown-item" href="selectAll-patient"><i class="fa-solid fa-users"></i> View All Patients</a>
                        <a class="dropdown-item" href="deleteAll-patient"><i class="fa-solid fa-user-slash"></i> Delete All Patients</a>
                        <a class="dropdown-item" href="bmi_calculator"><i class="fa-solid fa-weight-scale"></i> BMI Calculator</a>
                    </div>
                </li>

                <!-- Logout Button -->
                <li class="nav-item">
                    <a class="nav-link" href="logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
                </li>

            </ul>
        </div>
    </div>
</nav>

<!-- Main Content -->
<div class="container">
    <div class="doctor-avatar">
        <i class="fa-solid fa-user-doctor"></i>
        <div class="speech-bubble">Hello Doctor! Ready to see your patients today?</div>
    </div>

    <div class="welcome-msg">Welcome to your Dashboard</div>

    <h4 class="text-secondary">Check Today's Appointments</h4>

    <form action="doctor-appointments" class="form-inline justify-content-center mt-3">
        <div class="form-group mb-2">
            <label for="doctorName" class="sr-only">Doctor Name</label>
            <input type="text" class="form-control" id="doctorName" name="doctorName"
                placeholder="Enter your name" required>
        </div>
        <button type="submit" class="btn btn-appointments mb-2 ml-2">
            <i class="fa-solid fa-calendar-check"></i> Check Appointments
        </button>
    </form>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
// Doctor speech animation: bubble changes text every few seconds
const phrases = [
    "Let's start healing lives! 💉",
    "Remember to take short breaks ☕",
    "Ready to check your appointments? 🗓️",
    "Patients are waiting with smiles 🙂"
];
let idx = 0;
setInterval(() => {
    const bubble = document.querySelector('.speech-bubble');
    bubble.textContent = phrases[idx];
    idx = (idx + 1) % phrases.length;
}, 4000);
</script>

</body>
</html>
