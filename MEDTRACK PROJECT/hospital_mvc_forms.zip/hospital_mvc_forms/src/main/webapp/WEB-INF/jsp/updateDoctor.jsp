<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Update Doctor</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f0f2f5;
        }
        .card {
            border-radius: 20px;
            box-shadow: 0px 4px 20px rgba(0,0,0,0.1);
        }
        .card-header {
            border-radius: 20px 20px 0 0;
            background: linear-gradient(45deg, #4e73df, #1cc88a);
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .form-control, .form-select {
            border-radius: 12px;
        }
        .btn-custom {
            border-radius: 12px;
            background: #4e73df;
            color: white;
        }
        .btn-custom:hover {
            background: #1cc88a;
            color: white;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header text-center">
                    Update Doctor
                </div>
                <div class="card-body">
                    <form action="update-doctor"  enctype="multipart/form-data">
                        
                        <!-- Doctor ID (readonly for update) -->
                        <div class="mb-3">
                            <label class="form-label">Doctor ID</label>
                            <input type="text" class="form-control" name="doctorId" value="${doctor.doctorId}" >
                        </div>
                        
                        <!-- Name & Gender -->
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Name</label>
                                <input type="text" class="form-control" name="name" value="${doctor.name}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Gender</label>
                                <select class="form-select" name="gender" required>
                                    <option value="">Select Gender</option>
                                    <option ${doctor.gender == 'Male' ? 'selected' : ''}>Male</option>
                                    <option ${doctor.gender == 'Female' ? 'selected' : ''}>Female</option>
                                    <option ${doctor.gender == 'Other' ? 'selected' : ''}>Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <!-- DOB & Contact -->
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" name="dateOfBirth" value="${doctor.dateOfBirth}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Contact Number</label>
                                <input type="text" class="form-control" name="contactNumber" value="${doctor.contactNumber}" required pattern="[0-9]{10}">
                            </div>
                        </div>
                        
                        <!-- Email & Qualification -->
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="text" class="form-control" name="email" value="${doctor.email}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Qualification</label>
                                <input type="text" class="form-control" name="qualification" value="${doctor.qualification}" required>
                            </div>
                        </div>
                        
                        <!-- Specialization & Experience -->
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Specialization</label>
                                <input type="text" class="form-control" name="specialization" value="${doctor.specialization}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Experience (Years)</label>
                                <input type="text" class="form-control" name="experience" value="${doctor.experience}" min="0" required>
                            </div>
                        </div>
                        
                        <!-- License & Fee -->
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">License Number</label>
                                <input type="text" class="form-control" name="licenseNumber" value="${doctor.licenseNumber}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Consultation Fee (₹)</label>
                                <input type="text" class="form-control" name="consultationFee" value="${doctor.consultationFee}" min="0" required>
                            </div>
                        </div>
                        
                        <!-- Working Hours & Availability -->
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Working Hours</label>
                                <input type="text" class="form-control" name="workingHours" value="${doctor.workingHours}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Availability Status</label>
                                <select class="form-select" name="availabilityStatus" required>
                                    <option value="">Select Status</option>
                                    <option ${doctor.availabilityStatus == 'Available' ? 'selected' : ''}>Available</option>
                                    <option ${doctor.availabilityStatus == 'On Leave' ? 'selected' : ''}>On Leave</option>
                                    <option ${doctor.availabilityStatus == 'Not Available' ? 'selected' : ''}>Not Available</option>
                                </select>
                            </div>
                        </div>
                        
                        <!-- Joining Date -->
                        <div class="mb-3">
                            <label class="form-label">Joining Date</label>
                            <input type="date" class="form-control" name="joiningDate" value="${doctor.joiningDate}" required>
                        </div>
                        
                        <!-- Address -->
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <textarea class="form-control" name="address" rows="3" required>${doctor.address}</textarea>
                        </div>
                        
                        <!-- Photo -->
                        <div class="mb-3">
                            <label class="form-label">Doctor Photo</label>
                            <input type="text" class="form-control" name="photo_url" >
                            <small class="text-muted">Current: ${doctor.photo_url}</small>
                        </div>
                        
                        <!-- Submit -->
                        <div class="text-center">
                            <button type="submit" class="btn btn-custom px-5">Update Doctor</button>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
