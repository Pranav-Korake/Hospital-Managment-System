<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Update Appointment Status</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" 
          href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2>Update Appointment Status</h2>
    <form action="update-appointmentdto-status" method="post" class="form-horizontal">
        <!-- Hidden field to pass appointmentId -->
        <input type="hidden" name="appointmentId" value="${appointmentId}" />

        <!-- Patient Name (read-only) -->
        <div class="form-group">
            <label class="control-label col-sm-2">Patient Name:</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" value="${patientName}" readonly>
            </div>
        </div>

        <!-- Date (read-only) -->
        <div class="form-group">
            <label class="control-label col-sm-2">Date:</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" value="${date}" readonly>
            </div>
        </div>

        <!-- Time Slot (read-only) -->
        <div class="form-group">
            <label class="control-label col-sm-2">Time Slot:</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" value="${timeSlot}" readonly>
            </div>
        </div>

        <!-- Status (editable) -->
        <div class="form-group">
            <label class="control-label col-sm-2">Status:</label>
            <div class="col-sm-10">
                <select class="form-control" name="status">
                    <option value="Scheduled" ${status eq 'Scheduled' ? 'selected' : ''}>Scheduled</option>
                    <option value="Completed" ${status eq 'Completed' ? 'selected' : ''}>Completed</option>
                    <option value="Cancelled" ${status eq 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                </select>
            </div>
        </div>

        <!-- Submit button -->
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary">Update Status</button>
            </div>
        </div>
    </form>
</div>
</body>
</html>
