<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Search Appointments by Doctor</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Search Appointments by Doctor Name</h2>
    <form action="appointments-by-doctor" >
        <div class="form-group">
            <label for="doctorName">Doctor Name:</label>
            <input type="text" name="doctorName" id="doctorName" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Search</button>
    </form>
</div>
</body>
</html>
