<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Employee</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Delete Employee</h2>
    <form action="delete-employee" >
        <!-- Employee ID -->
        <div class="mb-3">
            <label for="employeeId" class="form-label">Employee ID</label>
            <input type="text" class="form-control" id="employeeId" name="employeeId" required>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-danger">Delete Employee</button>
    </form>
</div>
</body>
</html>
