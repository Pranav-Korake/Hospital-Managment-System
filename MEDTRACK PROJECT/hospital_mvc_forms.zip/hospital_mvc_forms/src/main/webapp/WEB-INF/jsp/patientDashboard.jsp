<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Patient Dashboard - Galaxy Hospital</title>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
body {
    font-family: "Poppins", sans-serif;
    background: linear-gradient(135deg, #e0f7fa, #f8f9fa, #ffffff);
    overflow-x: hidden;
}

/* Navbar */
.navbar {
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    animation: slideDown 0.8s ease;
}
.navbar-brand { font-weight: bold; font-size: 1.4rem; }

/* Dashboard Buttons */
.container {
    margin-top: 70px;
    text-align: center;
    animation: fadeIn 1s ease;
}
.btn-dashboard {
    display: inline-block;
    width: 220px;
    margin: 15px;
    padding: 20px 0;
    font-size: 16px;
    font-weight: 600;
    border-radius: 14px;
    color: white;
    background: linear-gradient(90deg, #0083b0, #00b4db);
    transition: all 0.4s ease;
    text-decoration: none;
    box-shadow: 0 6px 12px rgba(0,131,176,0.3);
    position: relative;
    overflow: hidden;
}
.btn-dashboard i {
    font-size: 22px;
    margin-right: 8px;
}
.btn-dashboard:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,180,219,0.4);
    color: white;
}

/* Animated hover shine effect */
.btn-dashboard::before {
    content: "";
    position: absolute;
    top: 0;
    left: -75px;
    width: 50px;
    height: 100%;
    background: rgba(255,255,255,0.3);
    transform: skewX(-25deg);
    transition: left 0.75s ease;
}
.btn-dashboard:hover::before { left: 250px; }

.footer {
    margin-top: 60px;
    font-size: 14px;
    color: #888;
    text-align:center;
    animation: fadeIn 1.5s ease;
}

/* Chat Container */
#chatContainer {
    height: 400px;
    overflow-y: auto;
    background:#f1f1f1;
    padding:10px;
    border-radius: 8px;
}
.chat-message { margin:10px 0; }

/* Floating patient illustration animations */
.floating-icon {
    position: absolute;
    opacity: 0.1;
    animation: float 6s ease-in-out infinite;
}
.icon1 { top: 15%; left: 5%; font-size: 70px; color: #00b4db; animation-delay: 0s; }
.icon2 { bottom: 20%; right: 10%; font-size: 80px; color: #0083b0; animation-delay: 2s; }
.icon3 { top: 50%; right: 20%; font-size: 60px; color: #00799c; animation-delay: 4s; }

/* Animations */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}
@keyframes slideDown {
    from { transform: translateY(-50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-15px); }
}
</style>
</head>
<body>

<!-- Floating icons for soft hospital ambiance -->
<i class="fa-solid fa-user-nurse floating-icon icon1"></i>
<i class="fa-solid fa-stethoscope floating-icon icon2"></i>
<i class="fa-solid fa-syringe floating-icon icon3"></i>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><i class="fa-solid fa-hospital"></i> Galaxy Hospital</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse"
        data-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a class="nav-link" href="logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Dashboard Buttons -->
<div class="container">
    <a href="#" class="btn-dashboard" data-toggle="modal" data-target="#phoneModal"><i class="fa-solid fa-calendar-plus"></i> Book Appointment</a>
    <a href="all-prescriptions.jsp" class="btn-dashboard"><i class="fa-solid fa-file-medical"></i> See Prescriptions</a>
    <a href="bmi_calculator" class="btn-dashboard"><i class="fa-solid fa-heart-pulse"></i> BMI Calculator</a>
    <a href="#" class="btn-dashboard" data-toggle="modal" data-target="#chatbotModal"><i class="fa-solid fa-robot"></i> Chatbot</a>
    <a href="add-patient-form" class="btn-dashboard"><i class="fa-solid fa-user-plus"></i> Register Patient</a>
</div>

<!-- Phone Modal -->
<div class="modal fade" id="phoneModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header bg-info text-white">
        <h5 class="modal-title"><i class="fa-solid fa-phone"></i> Enter Phone Number</h5>
        <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <input type="text" id="patientPhone" class="form-control" placeholder="Enter your phone number">
        <small class="form-text text-muted mt-2">We'll search your record in our database.</small>
        <div id="patientList" style="margin-top:20px;"></div>
        <div id="addPatientForm" style="display:none; margin-top:20px;">
            <input type="text" id="newPatientName" class="form-control mb-2" placeholder="Enter Name">
            <input type="text" id="newPatientEmail" class="form-control mb-2" placeholder="Enter Email">
            <button type="button" class="btn btn-success btn-block" onclick="addPatient()">Add Patient & Book Appointment</button>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" onclick="searchPatient()">Search</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Chatbot Modal -->
<div class="modal fade" id="chatbotModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title"><i class="fa-solid fa-robot"></i> Chat with Galaxy Assistant</h5>
        <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body" id="chatContainer"></div>
      <div class="modal-footer">
        <input type="text" id="chatInput" class="form-control" placeholder="Type your message..." style="flex:1">
        <button type="button" class="btn btn-primary" id="chatSendBtn">Send</button>
      </div>
    </div>
  </div>
</div>

<footer class="footer">© 2025 Galaxy Hospital. All rights reserved.</footer>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Patient search & add
function searchPatient() {
    const phone = $('#patientPhone').val().trim();
    if(!phone){ alert('Please enter your phone number.'); return; }
    fetch('http://localhost:7171/patients/contactNumber/' + phone)
      .then(res => res.json())
      .then(data => {
        const patientListDiv = $('#patientList');
        patientListDiv.html('');
        $('#addPatientForm').hide();
        if(data && data.length > 0){
            patientListDiv.append('<h5>Select Patient:</h5>');
            data.forEach(p => {
                const btn = $('<button class="btn btn-info btn-block"></button>').text(p.name + ' (' + p.contactNumber + ')');
                btn.click(() => window.location.href = 'book-appointment?patientId=' + p.patientId);
                patientListDiv.append(btn);
            });
        } else { $('#addPatientForm').show(); }
      })
      .catch(err => { console.error(err); alert('Error searching patient.'); });
}

function addPatient() {
    const phone = $('#patientPhone').val().trim();
    const name = $('#newPatientName').val().trim();
    const email = $('#newPatientEmail').val().trim();
    if(!name || !email){ alert('Fill name and email'); return; }
    $.ajax({
        url: '/add-patient',
        method: 'POST',
        data: { name, email, contactNumber: phone },
        success: function(response) {
            if(response.success){
                $('#patientList').html(`<div class="alert alert-success">Patient added successfully!</div>
                    <button class="btn btn-primary btn-block" onclick="window.location.href='/book-appointment?patientId='+response.patientId">Book Appointment</button>`);
            } else { alert('Error adding patient.'); }
        },
        error: function() { alert('Error adding patient.'); }
    });
}

// Chatbot
function appendMessage(sender, message) {
    const chatContainer = document.getElementById('chatContainer');
    const msgDiv = document.createElement('div');
    msgDiv.classList.add('chat-message');
    msgDiv.innerHTML = `<strong>${sender}:</strong> ${message}`;
    chatContainer.appendChild(msgDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

async function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    if (!message) return;

    appendMessage('You', message);
    input.value = '';

    const dotsDiv = document.createElement('div');
    dotsDiv.id = 'typingDots';
    dotsDiv.innerHTML = '<strong>Assistant:</strong> ...';
    document.getElementById('chatContainer').appendChild(dotsDiv);

    try {
        const response = await fetch('http://localhost:7171/chatbot-api', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        });
        const data = await response.json();
        dotsDiv.remove();
        appendMessage('Assistant', data.reply);
    } catch (err) {
        console.error(err);
        dotsDiv.remove();
        appendMessage('Assistant', 'Sorry, something went wrong. Try again later.');
    }
}

document.getElementById('chatInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') sendMessage();
});
document.getElementById('chatSendBtn').addEventListener('click', sendMessage);
</script>

</body>
</html>
