<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hospital Management</title>
<!-- Bootstrap 4 CSS -->
<link rel="stylesheet"
	href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<!-- Font Awesome for icons -->
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
.navbar {
	box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.navbar-brand {
	font-weight: bold;
	font-size: 1.3rem;
}

.dropdown-menu {
	border-radius: 10px;
	box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
}

.dropdown-item:hover {
	background-color: #f1f1f1;
}
</style>
</head>
<body>

	<!-- Navbar -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<div class="container-fluid">
			<!-- Brand -->
			<a class="navbar-brand" href="#"><i class="fa-solid fa-hospital"></i>
				Hospital Management</a>

			<!-- Toggle for mobile -->
			<button class="navbar-toggler" type="button" data-toggle="collapse"
				data-target="#navbarNavDropdown">
				<span class="navbar-toggler-icon"></span>
			</button>

			<!-- Navbar Items -->
			<div class="collapse navbar-collapse" id="navbarNavDropdown">
				<ul class="navbar-nav ml-auto">

					<!-- Book Appointment -->
					<li class="nav-item active"><a class="nav-link" href="#"><i
							class="fa-solid fa-calendar-check"></i> Book Appointment</a></li>

					<!-- Doctor Dropdown -->
					<li class="nav-item dropdown"><a
						class="nav-link dropdown-toggle" href="#" id="doctorDropdown"
						role="button" data-toggle="dropdown"> <i
							class="fa-solid fa-user-doctor"></i> Doctor
					</a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="add-doctor-form"><i
								class="fa-solid fa-user-plus"></i> Add Doctor</a> <a
								class="dropdown-item" href="selectById-doctor-form"><i
								class="fa-solid fa-list"></i> View Doctors</a> <a
								class="dropdown-item" href="update-doctor-form"><i
								class="fa-solid fa-pen"></i> Update Doctor</a> <a
								class="dropdown-item" href="delete-doctor-form"><i
								class="fa-solid fa-trash"></i> Delete Doctor</a> <a
								class="dropdown-item" href="selectAll-doctor"><i
								class="fa-solid fa-trash"></i> Select All Doctors</a> <a
								class="dropdown-item" href="deleteAll-doctor"><i
								class="fa-solid fa-trash"></i> Delete All Doctors</a> <a
								class="dropdown-item" href="selectByName-doctor"><i
								class="fa-solid fa-trash"></i> Select By Name Doctor</a> <a
								class="dropdown-item" href="selectByQualification-doctor"><i
								class="fa-solid fa-trash"></i>Select Doctor By Qualification</a> <a
								class="dropdown-item" href="selectBySpecialization-doctor"><i
								class="fa-solid fa-trash"></i> Select Doctor By Specialization</a> <a
								class="dropdown-item" href="selectByExperience-doctor"><i
								class="fa-solid fa-trash"></i>Select Doctor By Experience</a>



						</div></li>

					<!-- Patient Dropdown -->
					<li class="nav-item dropdown"><a
						class="nav-link dropdown-toggle" href="#" id="patientDropdown"
						role="button" data-toggle="dropdown"> <i
							class="fa-solid fa-user"></i> Patient
					</a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="add-patient-form"><i
								class="fa-solid fa-user-plus"></i> Add Patient</a> <a
								class="dropdown-item" href="view-patients"><i
								class="fa-solid fa-list"></i> View Patients</a> <a
								class="dropdown-item" href="update-patient"><i
								class="fa-solid fa-pen"></i> Update Patient</a> <a
								class="dropdown-item" href="delete-patient"><i
								class="fa-solid fa-trash"></i> Delete Patient</a>
						</div></li>

					<!-- Employee Dropdown -->
					<li class="nav-item dropdown"><a
						class="nav-link dropdown-toggle" href="#" id="employeeDropdown"
						role="button" data-toggle="dropdown"> <i
							class="fa-solid fa-users"></i> Employee
					</a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="add-employee-form"><i
								class="fa-solid fa-user-plus"></i> Add Employee</a> <a
								class="dropdown-item" href="view-employees"><i
								class="fa-solid fa-list"></i> View Employees</a> <a
								class="dropdown-item" href="update-employee"><i
								class="fa-solid fa-pen"></i> Update Employee</a> <a
								class="dropdown-item" href="delete-employee"><i
								class="fa-solid fa-trash"></i> Delete Employee</a>
						</div></li>

				</ul>
			</div>
		</div>
	</nav>

	<!-- Bootstrap JS + jQuery -->
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<a href="login">Open</a>

</body>
</html>
