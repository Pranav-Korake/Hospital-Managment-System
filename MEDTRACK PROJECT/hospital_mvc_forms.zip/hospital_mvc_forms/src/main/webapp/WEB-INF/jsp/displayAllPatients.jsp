<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Patient Details</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"
	href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script
	src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script
	src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

	<div class="container">
		<table class="table table-striped">
			<thead>
				<tr>
					 <th>Patient ID</th>
        <th>Patient Name</th>
        <th>Gender</th>
        <th>Date of birth</th>
        <th>Contact Number</th>
        <th>Email</th>
        <th>Address</th>
        <th>Blood Group</th>
        <th>Age</th>
        <th>Weight</th>
        <th>Emergency Contact Name</th>
        <th>Emergency Contact Number</th>
        <th>Patient Photo</th>
        
				</tr>
			</thead>
			<tbody>
				<c:forEach items="${patientList }" var="d">
					<tr>
						<td>${d.patientId }</td>
        <td>${d.name }</td>
        <td>${d.gender }</td>
         <td>${d.dateOfBirth }</td>
          <td>${d.contactNumber }</td>
           <td>${d.email }</td>
            <td>${d.address }</td>
             <td>${d.bloodGroup }</td>
              <td>${d.age }</td>
               <td>${d.weight }</td>
                <td>${d.emergencyContactName }</td>
                 <td>${d.emergencyContactNumber }</td>
                 
                   <td>${d.patient_photo_url }</td>
                   
					</tr>
				</c:forEach>
			</tbody>
		</table>
	</div>

</body>
</html>
