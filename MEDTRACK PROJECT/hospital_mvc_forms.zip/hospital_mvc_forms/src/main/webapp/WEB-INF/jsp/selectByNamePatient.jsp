<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Find Patient</title>
    <!-- Optional Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Find Patient by Name</h2>
    <form action="selectByName-patient" method="get">
        
        <!-- Patient Name -->
        <div class="mb-3">
            <label for="name" class="form-label">Enter Patient Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>

        <!-- Submit -->
        <button type="submit" class="btn btn-primary">Search</button>
    </form>
</div>
</body>
</html>
