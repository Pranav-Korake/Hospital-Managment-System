<!DOCTYPE html>
<html lang="en">
<head>
  <title>Employee Details</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
   <table class="table table-striped">
    <thead>
      <tr>
        <th>Employee ID</th>
        <th>Employee Name</th>
        <th>Gender</th>
        <th>Date of birth</th>
        <th>Contact Number</th>
        <th>Email</th>
        <th>Address</th>
        <th>Role</th>
        <th>Joining Date</th>
        <th>salary</th>
        <th>shift</th>
        <th>status</th>
        <th>emp_photo_url</th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
         <td>${d.employeeId }</td>
        <td>${d.name }</td>
        <td>${d.gender }</td>
         <td>${d.dateOfBirth }</td>
          <td>${d.contactNumber }</td>
           <td>${d.email }</td>
            <td>${d.address }</td>
             <td>${d.role }</td>
              <td>${d.joiningDate }</td>
               <td>${d.salary }</td>
                <td>${d.shift }</td>
                 <td>${d.status }</td>
                  <td>${d.emp_photo_url }</td>
                  
      </tr>
    </tbody>
  </table>
</div>

</body>
</html>
