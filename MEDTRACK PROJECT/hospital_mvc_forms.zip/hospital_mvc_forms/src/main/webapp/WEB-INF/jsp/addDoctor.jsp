<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Doctor - Galaxy Hospital</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #74ABE2, #5563DE);
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    .container {
        background-color: #fff;
        padding: 40px 50px;
        border-radius: 20px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        width: 500px;
        animation: fadeIn 1s ease-in-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    h2 {
        text-align: center;
        color: #2C3E50;
        margin-bottom: 25px;
    }

    form label {
        display: block;
        margin-top: 15px;
        margin-bottom: 5px;
        font-weight: 600;
        color: #2C3E50;
    }

    form input, form select, form textarea {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #ccc;
        border-radius: 10px;
        font-size: 14px;
        transition: all 0.3s ease;
    }

    form input:focus, form select:focus, form textarea:focus {
        border-color: #5563DE;
        box-shadow: 0 0 8px rgba(85, 99, 222, 0.4);
        outline: none;
    }

    textarea {
        resize: none;
    }

    button {
        width: 100%;
        padding: 14px 0;
        margin-top: 20px;
        background-color: #5563DE;
        border: none;
        border-radius: 12px;
        color: #fff;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    button:hover {
        background-color: #3548B1;
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(0,0,0,0.2);
    }

    @media (max-width: 550px) {
        .container {
            width: 90%;
            padding: 30px 20px;
        }
    }
</style>
</head>
<body>

<div class="container">
    <h2>Add Doctor 🩺</h2>

    <form action="add-doctor" method="post">
        <label>Doctor ID:</label>
        <input type="text" name="doctorId" required>

        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Gender:</label>
        <select name="gender" required>
            <option value="">Select</option>
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
        </select>

        <label>Date of Birth:</label>
        <input type="date" name="dateOfBirth" required>

        <label>Contact Number:</label>
        <input type="text" name="contactNumber" required>

        <label>Email:</label>
        <input type="text" name="email" required>

        <label>Qualification:</label>
        <input type="text" name="qualification" required>

        <label>Specialization:</label>
        <input type="text" name="specialization" required>

        <label>Experience (years):</label>
        <input type="text" name="experience" required>

        <label>License Number:</label>
        <input type="text" name="licenseNumber" required>

        <label>Consultation Fee:</label>
        <input type="text" name="consultationFee" required>

        <label>Working Hours:</label>
        <input type="text" name="workingHours" placeholder="e.g. 10:00 AM - 5:00 PM" required>

        <label>Availability Status:</label>
        <select name="availabilityStatus" required>
            <option value="">Select</option>
            <option>Available</option>
            <option>On Leave</option>
            <option>Not Available</option>
        </select>

        <label>Joining Date:</label>
        <input type="date" name="joiningDate" required>

        <label>Address:</label>
        <textarea name="address" rows="3" required></textarea>

        <label>Photo URL:</label>
        <input type="text" name="photo_url">

        <button type="submit">Submit</button>
    </form>
</div>

</body>
</html>
