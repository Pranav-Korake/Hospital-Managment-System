<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Find Employee by Name</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Find Employee by Name</h2>
    <form action="selectByName-employee" >
        <!-- Employee Name -->
        <div class="mb-3">
            <label for="name" class="form-label">Employee Name</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Enter full or partial name" required>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Search</button>
    </form>
</div>
</body>
</html>
