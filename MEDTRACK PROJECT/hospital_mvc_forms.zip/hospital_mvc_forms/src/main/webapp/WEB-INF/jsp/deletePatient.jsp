<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Patient</title>
    <!-- Optional Bootstrap for styling -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4 text-danger">Delete Patient</h2>
    <form action="delete-patient" >
        
        <!-- Patient ID -->
        <div class="mb-3">
            <label for="patientId" class="form-label">Enter Patient ID</label>
            <input type="text" class="form-control" id="patientId" name="patientId" required>
        </div>

        <!-- Submit -->
        <button type="submit" class="btn btn-danger">Delete Patient</button>
    </form>
</div>
</body>
</html>
