<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Error Page</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .error-container {
            background-color: #fff3f3;
            border: 1px solid #f5c6cb;
            padding: 40px 60px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            text-align: center;
        }

        .error-container h3 {
            color: #d9534f;
            font-size: 24px;
            margin: 0;
        }

        .error-container p {
            color: #555;
            font-size: 16px;
            margin-top: 10px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 25px;
            color: #fff;
            background-color: #0275d8;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #025aa5;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <h3>${errorMsg}</h3>
        <p>Please check the input or try again later.</p>
        <a class="back-btn" href="javascript:history.back()">Go Back</a>
    </div>
</body>
</html>
