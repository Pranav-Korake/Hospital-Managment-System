<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>BMI Calculator - Galaxy Hospital</title>
    <link rel="stylesheet" 
          href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: "Poppins", sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 450px;
            margin-top: 80px;
            padding: 30px;
            background: #ffffff;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }
        h2 {
            margin-bottom: 20px;
            color: #0083b0;
        }
        .btn-submit {
            background-color: #0083b0;
            color: white;
            width: 100%;
        }
        .btn-submit:hover {
            background-color: #00b4db;
            color: white;
        }
        .result {
            margin-top: 20px;
            font-size: 18px;
            font-weight: 600;
        }
    </style>
</head>
<body>
<div class="container text-center">
    <h2>BMI Calculator</h2>

    <form action="calculate-bmi" method="post">
        <input type="number" name="weight" class="form-control mb-3" step="0.1" placeholder="Weight (kg)" required>
        <input type="number" name="height" class="form-control mb-3" step="0.01" placeholder="Height (m)" required>
        <button type="submit" class="btn btn-submit">Calculate BMI</button>
    </form>

    <div class="result">
        <% String bmiResult = (String) request.getAttribute("bmiResult");
           if (bmiResult != null) { %>
            <p><%= bmiResult %></p>
        <% } %>
    </div>
</div>
</body>
</html>
