package com.nt;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nt.dto.DoctorResponseDto;
import com.nt.entity.Appointment;
import com.nt.entity.AppointmentDTO;
import com.nt.entity.Doctor;
import com.nt.entity.Patient;
import com.nt.service.AppointmentService;
import com.nt.service.DoctorService;
import com.nt.service.PatientService;

@Controller
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private PatientService patientService;

    // Open appointment form for a patient
    @RequestMapping("/book-appointment")
    public String bookAppointmentForm(@RequestParam int patientId, Model model) {
        Appointment apt = new Appointment();

        // Fetch patient details from API
        Patient patient = new Patient();
        patient.setPatientId(patientId);
        apt.setPatient(patient);

        model.addAttribute("appointment", apt);

        // Fetch all doctors for dropdown
        List<DoctorResponseDto> doctorList = doctorService.selectAll();
        model.addAttribute("doctorList", doctorList);

        return "appointment";
    }

    // Handle form submit
    @RequestMapping("/add-appointment")
    public String addAppointment(@RequestParam int doctorId,
                                 @RequestParam int patientId,
                                 @RequestParam String patientName,
                                 @RequestParam String doctorName,
                                 @RequestParam String date,
                                 @RequestParam String timeSlot,
                                 @RequestParam int amount,
                                 @RequestParam String paymentMode,
                                 Model model) {

        Appointment apt = new Appointment();

        // Wrap IDs in Doctor and Patient objects
        Doctor d = new Doctor();
        d.setDoctorId(doctorId);
        apt.setDoctor(d);

        Patient p = new Patient();
        p.setPatientId(patientId);
        apt.setPatient(p);

        apt.setPatientName(patientName);
        apt.setDoctorName(doctorName);
        apt.setDate(java.time.LocalDate.parse(date));
        apt.setTimeSlot(timeSlot);
        apt.setAmount(amount);
        apt.setPaymentMode(paymentMode);
        apt.setStatus("Pending");

        boolean booked = appointmentService.addAppointment(apt);

        if (booked) {
            model.addAttribute("msg", "Appointment booked successfully!");
            return "success";
        } else {
            model.addAttribute("errorMsg", "Cannot book appointment!");
            return "error";
        }
    }
    
    
    @RequestMapping("/appointments-by-doctor-form")
    public String appointmentsByDoctorForm() {
        return "appointmentsByDoctorForm"; // JSP page with search form
    }

    // Call service to fetch appointments from API
    @RequestMapping("/doctor-appointments")
    public String selectAppointmentByDoctorName(@RequestParam String doctorName , Model model)
	{
		List<AppointmentDTO> dtoList = appointmentService.selectByNameDoctor(doctorName);
		model.addAttribute("applist", dtoList);
		return "appointmentsByDoctor";
		
	}
    
    
  
    
    @RequestMapping("/update-appointmentdto-status")
    public String updateAppointment(@ModelAttribute AppointmentDTO dto , Model model)
    {
    	boolean isUpdated=appointmentService.updateAppointment(dto);
		if(isUpdated) {
		model.addAttribute("msg","Appointment Status Updated Successfully");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Update Appointment Status!!!");
			return "error";
		}
    }
    
    @RequestMapping("/update-appointment")
    public String updateAppointment(@RequestParam int appointmentId , Model model)
    {
    	model.addAttribute("appointmentId" , appointmentId);
    	
    	return "updateAppointmentForm";
    }
   
    
}
    
    

