package com.nt.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nt.dto.DoctorResponseDto;
import com.nt.dto.EmployeeRequestDto;
import com.nt.dto.EmployeeResponseDto;

@Service
public class EmployeeService {
	
	@Autowired
    private RestTemplate restTemplate;

    private final String EMPLOYEE_API_URL = "http://localhost:7171/employees";

	public boolean addEmployee(EmployeeRequestDto dto) {
		 HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_JSON);

	        HttpEntity<EmployeeRequestDto> entity = new HttpEntity<>(dto, headers);

	        try {
	            String response = restTemplate.postForObject(EMPLOYEE_API_URL, entity, String.class);
	            return "added".equalsIgnoreCase(response);
	        } catch (Exception e) {
	            e.printStackTrace();
	            return false;
	        }
	}

	public boolean updateEmployee(EmployeeRequestDto dto) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<EmployeeRequestDto> entity = new HttpEntity<>(dto, headers);
		ResponseEntity<String> temp = restTemplate.exchange(EMPLOYEE_API_URL, HttpMethod.PUT, entity, String.class);
		String res = temp.getBody();
		if (res.equals("updated"))
			return true;
		return false;
	}

	public boolean deleteEmployee(int employeeId) {
		String url = EMPLOYEE_API_URL+"/employeeId/"+employeeId;
		HttpHeaders headers = new HttpHeaders();
		//headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<Void> entity = new HttpEntity<>(headers);
		
		
		
		ResponseEntity<String> temp = restTemplate.exchange(url, HttpMethod.DELETE, entity, String.class);
		String res = temp.getBody();
		if (res.equals("deleted"))
			return true;
		return false;
	}

	public EmployeeResponseDto selectByIdEmployee(int employeeId) {
		String url = EMPLOYEE_API_URL+"/employeeId/"+employeeId;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ResponseEntity<EmployeeResponseDto> temp = restTemplate.exchange(url, HttpMethod.GET, entity,
				EmployeeResponseDto.class);
		return temp.getBody();
		
	}

	public List<EmployeeResponseDto> selectAllEmployee() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<EmployeeResponseDto>> responseType = new ParameterizedTypeReference<List<EmployeeResponseDto>>() {
		};
		ResponseEntity<List<EmployeeResponseDto>> temp = restTemplate.exchange(EMPLOYEE_API_URL, HttpMethod.GET, entity, responseType);
		return temp.getBody();
	}

	public boolean deleteAll() {
		HttpHeaders headers = new HttpHeaders();
		
		HttpEntity<Void> entity = new HttpEntity<>(headers);
		
		
		ResponseEntity<String> temp = restTemplate.exchange(EMPLOYEE_API_URL, HttpMethod.DELETE, entity, String.class);
		String res = temp.getBody();
		if (res.equals("all deleted"))
			return true;
		return false;
	}

	public List<EmployeeResponseDto> selectByNameEmployee(String name) {
		String url= EMPLOYEE_API_URL+"/name/"+name;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<EmployeeResponseDto>> responseType = new ParameterizedTypeReference<List<EmployeeResponseDto>>() {
		};
		ResponseEntity<List<EmployeeResponseDto>> temp = restTemplate.exchange(url, HttpMethod.GET, entity, responseType);
		return temp.getBody();
	}

	public List<EmployeeResponseDto> selectByRoleEmployee(String role) {
		String url= EMPLOYEE_API_URL+"/role/"+role;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<EmployeeResponseDto>> responseType = new ParameterizedTypeReference<List<EmployeeResponseDto>>() {
		};
		ResponseEntity<List<EmployeeResponseDto>> temp = restTemplate.exchange(url, HttpMethod.GET, entity, responseType);
		return temp.getBody();
	}
    
    
    


}
