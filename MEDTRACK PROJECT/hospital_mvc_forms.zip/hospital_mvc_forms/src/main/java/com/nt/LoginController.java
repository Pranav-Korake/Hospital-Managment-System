package com.nt;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

  
    @RequestMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @RequestMapping(value = "/loginLogic")
    public String loginLogic(
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            @RequestParam("role") String role,
            Model model,
            HttpSession session) {

        // Simple validation: username must equal password
        if (username != null && password != null && username.equals(password)) {

            // Store session info
            session.setAttribute("username", username);
            session.setAttribute("role", role);

            // Redirect based on role
            switch (role.toLowerCase()) {
                case "doctor":
                    return "doctorDashboard";
                case "patient":
                    return "patientDashboard";
                case "admin":
                    return "adminDashboard";
                default:
                    model.addAttribute("errorMsg", "Invalid role selected!");
                    return "login";
            }
        } else {
            // Invalid login
            model.addAttribute("errorMsg", "Invalid username or password!");
            return "login";
        }
    }

  
}
