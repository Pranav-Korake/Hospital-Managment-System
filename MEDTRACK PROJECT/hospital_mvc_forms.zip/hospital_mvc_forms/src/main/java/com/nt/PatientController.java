package com.nt;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nt.dto.DoctorResponseDto;
import com.nt.dto.PatientRequestDto;
import com.nt.dto.PatientResponseDto;
import com.nt.service.PatientService;

@Controller
public class PatientController {
	
	@Autowired
	private PatientService service;
	
	@RequestMapping("/add-patient-form")
	public String addPatientForm()
	{
		return "addPatient";
	}
	

	@RequestMapping("/update-patient-form")
	public String updatePatientForm()
	{
		return "updatePatient";
	}
	
	@RequestMapping("/delete-patient-form")
	public String deletePatientForm()
	{
		return "deletePatient";
	}
	
	
	@RequestMapping("/selectById-patient-form")
	public String selectByIdPatientForm()
	{
		return "selectByIdPatient";
	}
	
	@RequestMapping("/selectByName-patient-form")
	public String selectByNamePatientForm()
	{
		return "selectByNamePatient";
	}
	
	@RequestMapping(value="/add-patient1" , method=RequestMethod.POST)
	public String addPatient(@ModelAttribute PatientRequestDto dto, Model model)
	{
		boolean isAdded=service.addPatient(dto);
		if(isAdded) {
		model.addAttribute("msg","Patient Added Successfully");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Add Patient");
			return "error";
		}
	}
	
	@RequestMapping(value="/update-patient" , method=RequestMethod.POST)
	public String updatePatient(@ModelAttribute PatientRequestDto dto, Model model)
	{
		 System.out.println("Updating patient: " + dto);
		boolean isUpdated=service.updatePatient(dto);
		if(isUpdated) {
		model.addAttribute("msg","Patient Updated Successfully");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Update Patient");
			return "error";
		}
	}
	
	@RequestMapping(value="/delete-patient")
	public String deletePatient(@RequestParam int patientId , Model model)
	{
		boolean isDeleted=service.deletePatient(patientId);
		if(isDeleted) {
		model.addAttribute("msg","Patient Deleted Successfully");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Delete Patient");
			return "error";
		}
				
	}
	
	@RequestMapping(value="/selectById-patient")
	public String selectByIdPatient(@RequestParam int patientId , Model model)
	{
		PatientResponseDto dto = service.selectByIdPatient(patientId);
		model.addAttribute("d", dto);
		return "displayPatient";
		
	}
	
	@RequestMapping(value="/selectByName-patient")
	public String selectByNamePatient(@RequestParam String name , Model model)
	{
		List<PatientResponseDto> dtoList = service.selectByNamePatient(name);
		model.addAttribute("patientList", dtoList);
		return "displayAllPatients";
		
	}
	
	@RequestMapping(value="/selectAll-patient")
	public String selectAllPatients(Model model)
	{
		List<PatientResponseDto> dtoList = service.selectAllPatients();
		model.addAttribute("patientList", dtoList);
		return "displayAllPatients";
		
	}
	
	
	@RequestMapping(value="/deleteAll-patient")
	public String deleteAllPatient(Model model)
	{
		boolean isDeleted=service.deleteAllPatient();
		if(isDeleted) {
		model.addAttribute("msg","Patients Deleted Successfully");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Delete Patients");
			return "error";
		}
	}
	
	

    @RequestMapping("/bmi_calculator")
    public String showBmiForm() {
        return "bmi_calculator"; // displays bmi-calculator.jsp
    }
	
	
    
    @RequestMapping("/calculate-bmi")
    public String calculateBmi(@RequestParam("weight") double weight,
                               @RequestParam("height") double height,
                               Model model) {

        if (height <= 0) {
            model.addAttribute("bmiResult", "Height must be greater than 0!");
            return "bmi-calculator";
        }

        double bmi = weight / (height * height);
        String category;

        if (bmi < 18.5) category = "Underweight";
        else if (bmi < 24.9) category = "Normal weight";
        else if (bmi < 29.9) category = "Overweight";
        else category = "Obesity";

        model.addAttribute("bmiResult", String.format("Your BMI: %.2f (%s)", bmi, category));
        return "bmi_calculator";
    }
    
    @RequestMapping(value="/add-patient", method=RequestMethod.POST)
    @ResponseBody
    public Map<String,Object> addPatientAjax(@ModelAttribute PatientRequestDto dto) {
        Map<String,Object> map = new HashMap<>();
        boolean isAdded = service.addPatient(dto);

        if(isAdded) {
            // Fetch the newly added patient by name
            List<PatientResponseDto> list = service.selectByNamePatient(dto.getName());
            if(!list.isEmpty()) {
                PatientResponseDto patient = list.get(0);
                map.put("success", true);
                map.put("patientId", patient.getPatientId());
            } else {
                map.put("success", false);
            }
        } else {
            map.put("success", false);
        }
        return map;
    }

   
}
    
	

