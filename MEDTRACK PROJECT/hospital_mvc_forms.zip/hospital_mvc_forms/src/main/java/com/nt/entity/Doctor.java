package com.nt.entity;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;


public class Doctor {

	private int doctorId;
	private String name;
	private String gender;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateOfBirth;
	private String contactNumber;
	private String email;
	private String qualification;
	private String specialization;
	private int experience;
	private String licenseNumber;
	private int consultationFee;
	private String workingHours;
	private String availabilityStatus;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate joiningDate;
	private String address;
	private String photo_url;
	public Doctor() {
		super();
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getLicenseNumber() {
		return licenseNumber;
	}
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	public int getConsultationFee() {
		return consultationFee;
	}
	public void setConsultationFee(int consultationFee) {
		this.consultationFee = consultationFee;
	}
	public String getWorkingHours() {
		return workingHours;
	}
	public void setWorkingHours(String workingHours) {
		this.workingHours = workingHours;
	}
	public String getAvailabilityStatus() {
		return availabilityStatus;
	}
	public void setAvailabilityStatus(String availabilityStatus) {
		this.availabilityStatus = availabilityStatus;
	}
	public LocalDate getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoto_url() {
		return photo_url;
	}
	public void setPhoto_url(String photo_url) {
		this.photo_url = photo_url;
	}
	public Doctor(int doctorId, String name, String gender, LocalDate dateOfBirth, String contactNumber, String email,
			String qualification, String specialization, int experience, String licenseNumber, int consultationFee,
			String workingHours, String availabilityStatus, LocalDate joiningDate, String address, String photo_url) {
		super();
		this.doctorId = doctorId;
		this.name = name;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		this.email = email;
		this.qualification = qualification;
		this.specialization = specialization;
		this.experience = experience;
		this.licenseNumber = licenseNumber;
		this.consultationFee = consultationFee;
		this.workingHours = workingHours;
		this.availabilityStatus = availabilityStatus;
		this.joiningDate = joiningDate;
		this.address = address;
		this.photo_url = photo_url;
	}
	
	
	
}
