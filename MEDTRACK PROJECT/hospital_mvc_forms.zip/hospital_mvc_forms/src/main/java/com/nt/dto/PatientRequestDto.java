package com.nt.dto;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

public class PatientRequestDto {
	
	@Override
	public String toString() {
		return "PatientRequestDto [patientId=" + patientId + ", name=" + name + ", gender=" + gender + ", dateOfBirth="
				+ dateOfBirth + ", contactNumber=" + contactNumber + ", email=" + email + ", address=" + address
				+ ", bloodGroup=" + bloodGroup + ", age=" + age + ", weight=" + weight + ", emergencyContactName="
				+ emergencyContactName + ", emergencyContactNumber=" + emergencyContactNumber + ", patient_photo_url="
				+ patient_photo_url + ", getPatientId()=" + getPatientId() + ", getName()=" + getName()
				+ ", getGender()=" + getGender() + ", getDateOfBirth()=" + getDateOfBirth() + ", getContactNumber()="
				+ getContactNumber() + ", getEmail()=" + getEmail() + ", getAddress()=" + getAddress()
				+ ", getBloodGroup()=" + getBloodGroup() + ", getAge()=" + getAge() + ", getWeight()=" + getWeight()
				+ ", getEmergencyContactName()=" + getEmergencyContactName() + ", getEmergencyContactNumber()="
				+ getEmergencyContactNumber() + ", getPatient_photo_url()=" + getPatient_photo_url() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	private int patientId;
	private String name;
	private String gender;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateOfBirth;
	private String contactNumber;
	private String email;
	private String address;
	private String bloodGroup;
	private int age;
	private int weight;
	private String emergencyContactName;
	private String emergencyContactNumber;
	private String patient_photo_url;
	public PatientRequestDto(int patientId, String name, String gender, LocalDate dateOfBirth, String contactNumber, String email,
			String address, String bloodGroup, int age, int weight, String emergencyContactName,
			String emergencyContactNumber, String patient_photo_url) {
		super();
		this.patientId = patientId;
		this.name = name;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		this.email = email;
		this.address = address;
		this.bloodGroup = bloodGroup;
		this.age = age;
		this.weight = weight;
		this.emergencyContactName = emergencyContactName;
		this.emergencyContactNumber = emergencyContactNumber;
		this.patient_photo_url = patient_photo_url;
	}
	public PatientRequestDto() {
		super();
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public String getEmergencyContactName() {
		return emergencyContactName;
	}
	public void setEmergencyContactName(String emergencyContactName) {
		this.emergencyContactName = emergencyContactName;
	}
	public String getEmergencyContactNumber() {
		return emergencyContactNumber;
	}
	public void setEmergencyContactNumber(String emergencyContactNumber) {
		this.emergencyContactNumber = emergencyContactNumber;
	}
	public String getPatient_photo_url() {
		return patient_photo_url;
	}
	public void setPatient_photo_url(String patient_photo_url) {
		this.patient_photo_url = patient_photo_url;
	}
	
	
	
	
	

}
