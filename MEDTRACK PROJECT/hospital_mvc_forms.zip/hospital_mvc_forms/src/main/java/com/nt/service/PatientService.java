package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.nt.dto.DoctorResponseDto;
import com.nt.dto.PatientRequestDto;
import com.nt.dto.PatientResponseDto;

@Service
public class PatientService {
	
	@Autowired
    private RestTemplate restTemplate;

    private final String PATIENT_API_URL = "http://localhost:7171/patients";

	

	public boolean addPatient(PatientRequestDto dto)
	{
		 HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_JSON);

	        HttpEntity<PatientRequestDto> entity = new HttpEntity<>(dto, headers);

	        try {
	            String response = restTemplate.postForObject(PATIENT_API_URL, entity, String.class);
	            return "added".equalsIgnoreCase(response);
	        } catch (Exception e) {
	            e.printStackTrace();
	            return false;
	        }
	}



	public boolean updatePatient(PatientRequestDto dto) {
	
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON); // <-- important
		HttpEntity<PatientRequestDto> entity = new HttpEntity<>(dto, headers);

		    ResponseEntity<String> response = restTemplate.exchange(
		            PATIENT_API_URL,
		            HttpMethod.PUT,
		            entity,
		            String.class
		    );

		    return "updated".equalsIgnoreCase(response.getBody());
		}


	
	public boolean deletePatient(int patientId) {
		String url = PATIENT_API_URL+"/patientId/"+patientId;
		HttpHeaders headers = new HttpHeaders();
		//headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<Void> entity = new HttpEntity<>(headers);
		
		
		
		ResponseEntity<String> temp = restTemplate.exchange(url, HttpMethod.DELETE, entity, String.class);
		String res = temp.getBody();
		if (res.equals("deleted"))
			return true;
		return false;
	}




	public PatientResponseDto selectByIdPatient(int patientId) {
		String url = PATIENT_API_URL+"/patientId/"+patientId;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ResponseEntity<PatientResponseDto> temp = restTemplate.exchange(url, HttpMethod.GET, entity,
				PatientResponseDto.class);
		return temp.getBody();
	}



	public List<PatientResponseDto> selectByNamePatient(String name) {
		String url= PATIENT_API_URL+"/name/"+name;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<PatientResponseDto>> responseType = new ParameterizedTypeReference<List<PatientResponseDto>>() {
		};
		ResponseEntity<List<PatientResponseDto>> temp = restTemplate.exchange(url, HttpMethod.GET, entity, responseType);
		return temp.getBody();
	}



	public List<PatientResponseDto> selectAllPatients() {
		
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<PatientResponseDto>> responseType = new ParameterizedTypeReference<List<PatientResponseDto>>() {
		};
		ResponseEntity<List<PatientResponseDto>> temp = restTemplate.exchange(PATIENT_API_URL, HttpMethod.GET, entity, responseType);
		return temp.getBody();
	}



	public boolean deleteAllPatient() {
		
		HttpHeaders headers = new HttpHeaders();
		//headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<Void> entity = new HttpEntity<>(headers);
		
		
		
		ResponseEntity<String> temp = restTemplate.exchange(PATIENT_API_URL, HttpMethod.DELETE, entity, String.class);
		String res = temp.getBody();
		if (res.equals("all deleted"))
			return true;
		return false;
	}

	
	
	

}
