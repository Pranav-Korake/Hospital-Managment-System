package com.nt;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WardController {
	
	
	
	@RequestMapping("/ward")
	public String showWard()
	{
		return "ward";
	}

}
