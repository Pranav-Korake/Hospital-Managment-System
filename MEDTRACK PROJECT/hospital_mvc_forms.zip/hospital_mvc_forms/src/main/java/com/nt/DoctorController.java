package com.nt;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nt.dto.DoctorRequestDto;
import com.nt.dto.DoctorResponseDto;
import com.nt.service.DoctorService;

@Controller
public class DoctorController {
	
	
	@Autowired
	private DoctorService service;
	
	@RequestMapping("/")
	public String indexForm()
	{
		return "index";
	}
	
	@RequestMapping("/home1")
	public String home() {
	    return "home1"; 
	}

	@RequestMapping("/home2")
	public String home2() {
	    return "home2"; 
	}
	
	@RequestMapping("/home3")
	public String home3() {
	    return "home3"; 
	}
	
	@RequestMapping("/home4")
	public String home4() {
	    return "home4"; 
	}
	
	@RequestMapping("/add-doctor-form")
	public String addDoctorForm()
	{
		return "addDoctor";
	}

	@RequestMapping("/update-doctor-form")
	public String updateDoctorForm()
	{
		return "updateDoctor";
	}
	
	@RequestMapping("/delete-doctor-form")
	public String deleteByIdDoctorForm()
	{
		return "deleteByIdDoctor";
	}
	
	@RequestMapping("/selectByExperience-doctor-form")
	public String selectByExperienceDoctorForm()
	{
		return "selectByExperienceDoctor";
	}
	
	@RequestMapping("/selectById-doctor-form")
	public String selectByIdDoctorForm()
	{
		return "selectByIdDoctor";
	}
	
	@RequestMapping("/selectByName-doctor-form")
	public String selectByNameDoctorForm()
	{
		return "selectByNameDoctor";
	}
	
	@RequestMapping("/selectByQualification-doctor-form")
	public String selectByQualificationDoctorForm()
	{
		return "selectByQualificationDoctor";
	}
	
	@RequestMapping("/selectBySpecialization-doctor-form")
	public String selectBySpecializationDoctorForm()
	{
		return "selectBySpecializationDoctor";
	}
	
	
	
	@RequestMapping(value="/add-doctor",method=RequestMethod.POST)
	public String addDoctor(@ModelAttribute DoctorRequestDto dto , Model model)
	{
		boolean isAdded=service.addDoctor(dto);
		if(isAdded) {
		model.addAttribute("msg","Doctor Added Successfully");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Add Doctor");
			return "error";
		}
	}	
		
		
		@RequestMapping(value="/update-doctor")
		public String updateDoctor(@ModelAttribute DoctorRequestDto dto , Model model)
		{
			boolean isUpdated=service.updateDoctor(dto);
			if(isUpdated) {
			model.addAttribute("msg","Doctor Updated Successfully");
			return "success";
			}
			else
			{
				model.addAttribute("errorMsg", "Cannot Update Doctor");
				return "error";
			}
		
		}
			
			@RequestMapping(value="/delete-doctor")
			public String deleteDoctor(@RequestParam int doctorId , Model model)
			{
				boolean isDeleted=service.deleteDoctor(doctorId);
				if(isDeleted) {
				model.addAttribute("msg","Doctor Deleted Successfully");
				return "success";
				}
				else
				{
					model.addAttribute("errorMsg", "Cannot Delete Doctor");
					return "error";
				}
						
			}
			
			@RequestMapping(value="/selectById-doctor")
			public String selectByIdDoctor(@RequestParam int doctorId , Model model)
			{
				DoctorResponseDto dto = service.selectByIdDoctor(doctorId);
				model.addAttribute("d", dto);
				return "display";
				
			}
			
			@RequestMapping(value="/selectAll-doctor")
			public String selectAll(Model model)
			{
				List<DoctorResponseDto> dtoList = service.selectAll();
				model.addAttribute("doclist", dtoList);
				return "displayAll";
				
			}
			
	
			@RequestMapping(value="/deleteAll-doctor")
			public String deleteAll(Model model)
			{
				boolean isDeleted=service.deleteAll();
				if(isDeleted) {
				model.addAttribute("msg","All Doctors Deleted");
				return "success";
				}
				else
				{
					model.addAttribute("errorMsg", "Cannot Delete Doctor");
					return "error";
				}
				
			}
			
	
			@RequestMapping(value="/selectByName-doctor")
			public String selectByNameDoctor(@RequestParam String name , Model model)
			{
				List<DoctorResponseDto> dtoList = service.selectByNameDoctor(name);
				model.addAttribute("doclist", dtoList);
				return "displayAll";
				
			}
			
			
		
			@RequestMapping(value="/selectByQualification-doctor")
			public String selectByQualificationDoctor(@RequestParam String qualification , Model model)
			{
				List<DoctorResponseDto> dtoList = service.selectByQualificationDoctor(qualification);
				model.addAttribute("doclist", dtoList);
				return "displayAll";
				
			}
			
	
			@RequestMapping(value="/selectBySpecialization-doctor")
			public String selectBySpecializationDoctor(@RequestParam String specialization , Model model)
			{
				List<DoctorResponseDto> dtoList = service.selectBySpecializationDoctor(specialization);
				model.addAttribute("doclist", dtoList);
				return "displayAll";
				
			}
			
			@RequestMapping(value="/selectByExperience-doctor")
			public String selectByExperienceDoctor(@RequestParam int experience , Model model)
			{
				List<DoctorResponseDto> dtoList = service.selectByExperienceDoctor(experience);
				model.addAttribute("doclist", dtoList);
				return "displayAll";
				
			}
			
	
	
}
