package com.nt.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nt.dto.DoctorRequestDto;
import com.nt.dto.DoctorResponseDto;

@Service
public class DoctorService {
    
	@Autowired
    private RestTemplate restTemplate;

    private final String DOCTOR_API_URL = "http://localhost:7171/doctors";

    public boolean addDoctor(DoctorRequestDto dto) {
    	
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<DoctorRequestDto> entity = new HttpEntity<>(dto, headers);

        try {
            String response = restTemplate.postForObject(DOCTOR_API_URL, entity, String.class);
            return "added".equalsIgnoreCase(response);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    
    public boolean updateDoctor(DoctorRequestDto dto) {
    	
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<DoctorRequestDto> entity = new HttpEntity<>(dto, headers);
		ResponseEntity<String> temp = restTemplate.exchange(DOCTOR_API_URL, HttpMethod.PUT, entity, String.class);
		String res = temp.getBody();
		if (res.equals("updated"))
			return true;
		return false;
    }


	public boolean deleteDoctor(int doctorId) {
		String url = DOCTOR_API_URL+"/doctorId/"+doctorId;
		HttpHeaders headers = new HttpHeaders();
		//headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<Void> entity = new HttpEntity<>(headers);
		
		System.out.println("Calling DELETE: " + url);
		
		ResponseEntity<String> temp = restTemplate.exchange(url, HttpMethod.DELETE, entity, String.class);
		String res = temp.getBody();
		if (res.equals("deleted"))
			return true;
		return false;
	}


	public DoctorResponseDto selectByIdDoctor(int doctorId) {
		
		String url = DOCTOR_API_URL+"/doctorId/"+doctorId;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ResponseEntity<DoctorResponseDto> temp = restTemplate.exchange(url, HttpMethod.GET, entity,
				DoctorResponseDto.class);
		return temp.getBody();
		
		
	}


	public List<DoctorResponseDto> selectAll() {
		
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<DoctorResponseDto>> responseType = new ParameterizedTypeReference<List<DoctorResponseDto>>() {
		};
		ResponseEntity<List<DoctorResponseDto>> temp = restTemplate.exchange(DOCTOR_API_URL, HttpMethod.GET, entity, responseType);
		return temp.getBody();
		
		
	}


	public boolean deleteAll() {
		
		HttpHeaders headers = new HttpHeaders();
	
		HttpEntity<Void> entity = new HttpEntity<>(headers);
		
		
		ResponseEntity<String> temp = restTemplate.exchange(DOCTOR_API_URL, HttpMethod.DELETE, entity, String.class);
		String res = temp.getBody();
		if (res.equals("all deleted"))
			return true;
		return false;
	}


	public List<DoctorResponseDto> selectByNameDoctor(String name) {
		String url= DOCTOR_API_URL+"/name/"+name;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<DoctorResponseDto>> responseType = new ParameterizedTypeReference<List<DoctorResponseDto>>() {
		};
		ResponseEntity<List<DoctorResponseDto>> temp = restTemplate.exchange(url, HttpMethod.GET, entity, responseType);
		return temp.getBody();
	}


	public List<DoctorResponseDto> selectByQualificationDoctor(String qualification) {
		String url= DOCTOR_API_URL+"/qualification/"+qualification;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<DoctorResponseDto>> responseType = new ParameterizedTypeReference<List<DoctorResponseDto>>() {
		};
		ResponseEntity<List<DoctorResponseDto>> temp = restTemplate.exchange(url, HttpMethod.GET, entity, responseType);
		return temp.getBody();
	}


	public List<DoctorResponseDto> selectBySpecializationDoctor(String specialization) {
		String url= DOCTOR_API_URL+"/specialization/"+specialization;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<DoctorResponseDto>> responseType = new ParameterizedTypeReference<List<DoctorResponseDto>>() {
		};
		ResponseEntity<List<DoctorResponseDto>> temp = restTemplate.exchange(url, HttpMethod.GET, entity, responseType);
		return temp.getBody();
	}


	public List<DoctorResponseDto> selectByExperienceDoctor(int experience) {
		String url= DOCTOR_API_URL+"/experience/"+experience;
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ParameterizedTypeReference<List<DoctorResponseDto>> responseType = new ParameterizedTypeReference<List<DoctorResponseDto>>() {
		};
		ResponseEntity<List<DoctorResponseDto>> temp = restTemplate.exchange(url, HttpMethod.GET, entity, responseType);
		return temp.getBody();
	}
    
	
    
    
    
    
	}


