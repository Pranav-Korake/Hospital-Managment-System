package com.nt.entity;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

public class AppointmentDTO {

  
	private int appointmentId;
    private String patientName;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate date;
    private String timeSlot;
    private String status;
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public AppointmentDTO(int appointmentId, String patientName, LocalDate date, String timeSlot, String status) {
		super();
		this.appointmentId = appointmentId;
		this.patientName = patientName;
		this.date = date;
		this.timeSlot = timeSlot;
		this.status = status;
	}
	public AppointmentDTO() {
		super();
	}
	
  
}
