package com.nt;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nt.dto.DoctorResponseDto;
import com.nt.dto.EmployeeRequestDto;
import com.nt.dto.EmployeeResponseDto;
import com.nt.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	
	@RequestMapping("/add-employee-form")
	public String addEmployeeForm()
	{
		return "addEmployee";
	}
	

	@RequestMapping("/update-employee-form")
	public String updateEmployeeForm()
	{
		return "updateEmployee";
	}
	
	
	@RequestMapping("/delete-employee-form")
	public String deleteEmployeeForm()
	{
		return "deleteEmployee";
	}
	
	@RequestMapping("/selectById-employee-form")
	public String selectByIdEmployeeForm()
	{
		return "selectByIdEmployee";
	}
	
	@RequestMapping("/selectByName-employee-form")
	public String selectByNameEmployeeForm()
	{
		return "selectByNameEmployee";
	}

	@RequestMapping("/selectByRole-employee-form")
	public String selectByRoleEmployeeForm()
	{
		return "selectByRoleEmployee";
	}
	
	@RequestMapping("/selectByShiftAndRole-employee-form")
	public String selectByShiftAndRoleEmployeeForm()
	{
		return "selectByShiftAndRoleEmployee";
	}
	
	
	

	@RequestMapping(value="/add-employee",method=RequestMethod.POST)
	public String addEmployee(@ModelAttribute EmployeeRequestDto dto , Model model)
	{
		boolean isAdded=service.addEmployee(dto);
		if(isAdded) {
		model.addAttribute("msg","Employee Added Successfully");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Add Employee");
			return "error";
		}
	}	
		
	
	@RequestMapping(value="/update-employee")
	public String updateEmployee(@ModelAttribute EmployeeRequestDto dto , Model model)
	{
		boolean isUpdated=service.updateEmployee(dto);
		if(isUpdated) {
		model.addAttribute("msg","Employee Updated Successfully");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Update Employee");
			return "error";
		}
	
	}
	
	@RequestMapping(value="/delete-employee")
	public String deleteEmployee(@RequestParam int employeeId , Model model)
	{
		boolean isDeleted=service.deleteEmployee(employeeId);
		if(isDeleted) {
		model.addAttribute("msg","Employee Deleted Successfully");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Delete Employee");
			return "error";
		}
				
	}
	
	@RequestMapping(value="/selectById-employee")
	public String selectByIdEmployee(@RequestParam int employeeId , Model model)
	{
		EmployeeResponseDto dto = service.selectByIdEmployee(employeeId);
		model.addAttribute("d", dto);
		return "displayEmployee";
		
	}
	
	@RequestMapping(value="/selectAll-employee")
	public String selectAllEmployee(Model model)
	{
		List<EmployeeResponseDto> dtoList = service.selectAllEmployee();
		model.addAttribute("emplist", dtoList);
		return "displayAllEmployee";
		
	}
	
	
	@RequestMapping(value="/deleteAll-employee")
	public String deleteAll(Model model)
	{
		boolean isDeleted=service.deleteAll();
		if(isDeleted) {
		model.addAttribute("msg","All Employees Deleted");
		return "success";
		}
		else
		{
			model.addAttribute("errorMsg", "Cannot Delete Employees");
			return "error";
		}
		
	}
	
	
	@RequestMapping(value="/selectByName-employee")
	public String selectByNameEmployee(@RequestParam String name , Model model)
	{
		List<EmployeeResponseDto> dtoList = service.selectByNameEmployee(name);
		model.addAttribute("emplist", dtoList);
		return "displayAllEmployee";
		
	}
	
	@RequestMapping(value="/selectByRole-employee")
	public String selectByRoleEmployee(@RequestParam String role , Model model)
	{
		List<EmployeeResponseDto> dtoList = service.selectByRoleEmployee(role);
		model.addAttribute("emplist", dtoList);
		return "displayAllEmployee";
		
	}
	
	
}
