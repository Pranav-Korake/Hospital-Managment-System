package com.nt.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nt.entity.Appointment;
import com.nt.entity.AppointmentDTO;

@Service
public class AppointmentService {

    @Autowired
    private RestTemplate restTemplate;

    private final String APPOINTMENT_API_URL = "http://localhost:7171/appointments";

    public boolean addAppointment(Appointment apt) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Appointment> entity = new HttpEntity<>(apt, headers);

        try {
            String response = restTemplate.postForObject(APPOINTMENT_API_URL, entity, String.class);
            return "added".equalsIgnoreCase(response);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<AppointmentDTO> selectByNameDoctor(String doctorName) {
        String url = APPOINTMENT_API_URL + "/doctorName/" + doctorName;

        HttpHeaders headers = new HttpHeaders();
        HttpEntity<String> entity = new HttpEntity<>(headers);

        ParameterizedTypeReference<List<AppointmentDTO>> responseType =
                new ParameterizedTypeReference<List<AppointmentDTO>>() {};

        ResponseEntity<List<AppointmentDTO>> response =
                restTemplate.exchange(url, HttpMethod.GET, entity, responseType);

        return response.getBody(); 
    
    }

	public boolean updateAppointment(AppointmentDTO dto) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<AppointmentDTO> entity = new HttpEntity<>(dto, headers);
		ResponseEntity<String> temp = restTemplate.exchange(APPOINTMENT_API_URL, HttpMethod.PUT, entity, String.class);
		String res = temp.getBody();
		if (res.equals("updated"))
			return true;
		return false;
	}

	public AppointmentDTO getAppointmentById(int appointmentId) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
	

/*	public List<AppointmentDTO> selectByNameDoctor(String doctorName) {
		
		try {
		    String encodedName = URLEncoder.encode(doctorName, StandardCharsets.UTF_8.toString());
		    String url = APPOINTMENT_API_URL + "/doctorName/" + encodedName;

		    HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		    HttpEntity<String> entity = new HttpEntity<>(headers);

		    ResponseEntity<List<AppointmentDTO>> response = restTemplate.exchange(
		    	    url,
		    	    HttpMethod.GET,
		    	    entity,
		    	    new ParameterizedTypeReference<List<AppointmentDTO>>() {}
		    	);

		    return response.getBody();

		} catch (Exception e) {
		    e.printStackTrace();
		    return Collections.emptyList();
		}
	}

   /* public List<Appointment> getAppointmentsByDoctor(String doctorName) {
        try {
            // Encode doctor name to handle spaces and special characters
           // String encodedName = URLEncoder.encode(doctorName, StandardCharsets.UTF_8.toString());
            Appointment[] response = restTemplate.getForObject(
                APPOINTMENT_API_URL+"/doctorName/"+doctorName,
                Appointment[].class
            );
            return response != null ? Arrays.asList(response) : Collections.emptyList();
        } catch (Exception e) {
            e.printStackTrace();  // log error
            return Collections.emptyList();
        }
    }*/

