package com.nt;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;
import java.util.HashMap;
import java.util.Map;

@RestController
public class ChatbotController {

    @RequestMapping(value="/chatbot-api", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, String> chat(@RequestBody Map<String, String> payload) {
        String userMessage = payload.get("message");
        String reply = generateChatbotReply(userMessage); // Replace with OpenAI API call
        Map<String, String> response = new HashMap<>();
        response.put("reply", reply);
        return response;
    }

    private String generateChatbotReply(String message) {
        // Dummy static responses, replace with OpenAI API integration
        if(message.toLowerCase().contains("hello")) return "Hello! How can I assist you today?";
        if(message.toLowerCase().contains("appointment")) return "You can book or check your appointments using the dashboard buttons.";
        return "I'm here to help! Ask me anything about Galaxy Hospital services.";
    }
}
