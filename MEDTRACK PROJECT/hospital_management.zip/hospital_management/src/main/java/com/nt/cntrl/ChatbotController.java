package com.nt.cntrl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.nt.dto.ChatRequest;
import com.nt.service.ChatbotService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/chatbot-api")
public class ChatbotController {

    @Autowired
    private ChatbotService chatbotService;

    @PostMapping
    public ResponseEntity<Map<String,String>> chat(@RequestBody ChatRequest request) {
        String userMessage = request.getMessage();
        String reply = chatbotService.processMessage(userMessage);

        Map<String,String> response = new HashMap<>();
        response.put("reply", reply);

        return ResponseEntity.ok(response);
    }
}
