package com.nt.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.nt.entity.Appointment;
import com.nt.entity.AppointmentDTO;

@Component
public class AppointmentMapper {
	
	public static AppointmentDTO toDto(Appointment appointment) {
        if (appointment == null) return null;

        AppointmentDTO dto = new AppointmentDTO();
        dto.setAppointmentId(appointment.getAppointmentId());
        dto.setPatientName(appointment.getPatientName());
        dto.setDate(appointment.getDate());
        dto.setTimeSlot(appointment.getTimeSlot());
        dto.setStatus(appointment.getStatus());

        return dto;
    }
	
	public static List<AppointmentDTO> toDtoList(List<Appointment> appointments) {
        if (appointments == null) return null;
        return appointments.stream()
                           .map(AppointmentMapper::toDto)
                           .collect(Collectors.toList());
    }

	
	 public static Appointment toEntity(AppointmentDTO dto) {
	        if (dto == null) return null;

	        Appointment appointment = new Appointment();
	        appointment.setAppointmentId(dto.getAppointmentId());
	        appointment.setPatientName(dto.getPatientName());
	        appointment.setDate(dto.getDate());
	        appointment.setTimeSlot(dto.getTimeSlot());
	        appointment.setStatus(dto.getStatus());

	        // Note: Doctor and Patient entities are not set here. You need to set them separately.
	        return appointment;
	    }

}
