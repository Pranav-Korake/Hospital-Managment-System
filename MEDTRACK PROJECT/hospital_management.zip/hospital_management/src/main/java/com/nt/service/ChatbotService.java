package com.nt.service;

public interface ChatbotService {
    String processMessage(String userMessage);
}
