package com.nt.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nt.entity.Patient;

@Repository
public interface PatientDao extends CrudRepository<Patient, Integer> {
	
	List<Patient> findAll();
	List<Patient> findByName(String name);
	List<Patient> findBycontactNumber(String contactNumber);

}
