package com.nt.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nt.entity.ChatMessage;

@Repository
public interface ChatMessageRepository extends CrudRepository<ChatMessage, Integer> {
}
