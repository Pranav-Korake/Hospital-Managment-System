package com.nt.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.dao.AppointmentDao;
import com.nt.dao.DoctorDao;
import com.nt.dao.PatientDao;
import com.nt.entity.Appointment;
import com.nt.entity.AppointmentDTO;
import com.nt.entity.Doctor;
import com.nt.entity.Patient;
import com.nt.mapper.AppointmentMapper;

@Service
public class AppointmentServiceImpl implements AppointmentService {
	
	@Autowired
	private AppointmentDao dao;
	
	@Autowired
    private DoctorDao doctorDao;

    @Autowired
    private PatientDao patientDao;
    
    
    @Autowired
    private AppointmentMapper mapper;

	@Override
	public void add(Appointment apt) throws RuntimeException {
		if (apt.getDoctor() != null) {
            Doctor d = doctorDao.findById(apt.getDoctor().getDoctorId())
                    .orElseThrow(() -> new RuntimeException("Doctor not found with id: " + apt.getDoctor().getDoctorId()));
            apt.setDoctor(d);
            apt.setDoctorName(d.getName());
        }

        // Set patient and patientName
        if (apt.getPatient() != null) {
            Patient p = patientDao.findById(apt.getPatient().getPatientId())
                    .orElseThrow(() -> new RuntimeException("Patient not found with id: " + apt.getPatient().getPatientId()));
            apt.setPatient(p);
            apt.setPatientName(p.getName());
        }

        // Save appointment
        dao.save(apt);
    
		
	}
	
	

	@Override
	public void update(AppointmentDTO apt) {
		Appointment a = mapper.toEntity(apt);
		dao.save(a);	
	}

	@Override
	public void delete() {
		dao.deleteAll();
		
	}

	@Override
	public void delete(int appointmentId) {
		dao.deleteById(appointmentId);
		
	}

	@Override
	public AppointmentDTO getById(int appointmentId) {
		Optional<Appointment> apt= dao.findById(appointmentId);
		
		AppointmentDTO dto = mapper.toDto(apt.get());
		
		return dto;
	}

	@Override
	public List<Appointment> getAll() {
		List<Appointment> list=dao.findAll();
		return list;
	}

	@Override
	public List<AppointmentDTO> getAllByDoctorName(String doctorName) {
		List<Appointment> dlist=dao.findByDoctorNameContainingIgnoreCase(doctorName);
		List<AppointmentDTO> list=mapper.toDtoList(dlist);
		return list;
	}

	@Override
	public List<Appointment> getAllByDate(LocalDate date) {
		List<Appointment> list=dao.findByDate(date);
		return list;
	}

	@Override
	public List<Appointment> getByDate(LocalDate date) {
		return dao.findByDate(date);
	}



	
	
}







	
	



