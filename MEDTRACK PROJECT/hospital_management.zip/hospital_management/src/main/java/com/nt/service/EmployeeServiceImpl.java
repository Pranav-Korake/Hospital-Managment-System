package com.nt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.dao.EmployeeDao;
import com.nt.dto.EmployeeRequestDto;
import com.nt.dto.EmployeeResponseDto;
import com.nt.entity.Employee;
import com.nt.mapper.EmployeeMapper;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeDao dao;
	
	@Autowired
	private EmployeeMapper mapper;

	@Override
	public void add(EmployeeRequestDto dto) {
		Employee e=mapper.toEntity(dto);
		dao.save(e);
		
		
	}

	@Override
	public void update(EmployeeRequestDto dto) {
		Employee e=mapper.toEntity(dto);
		dao.save(e);
		
	}

	@Override
	public void deleteById(int employeeId) {
		dao.deleteById(employeeId);
		
		
	}

	@Override
	public void deleteAll() {
		dao.deleteAll();
	}

	@Override
	public EmployeeResponseDto selectById(int employeeId) {
		
		Optional<Employee> opt=dao.findById(employeeId);
		Employee e=opt.get();
		EmployeeResponseDto dto=mapper.toDto(e);
		return dto;
	}

	@Override
	public List<EmployeeResponseDto> selectAll() {
		List<Employee> elist=dao.findAll();
		List<EmployeeResponseDto> list=mapper.toDtoList(elist);
		return list;
	}

	@Override
	public List<EmployeeResponseDto> selectByName(String name) {
		List<Employee> elist=dao.findByName(name);
		List<EmployeeResponseDto> list=mapper.toDtoList(elist);
		return list;
	}

	@Override
	public List<EmployeeResponseDto> selectByRole(String role) {
		List<Employee> elist=dao.findByRole(role);
		List<EmployeeResponseDto> list=mapper.toDtoList(elist);
		return list;
	}

	@Override
	public List<EmployeeResponseDto> findByShiftAndRole(String shift, String role) {
		List<Employee> elist=dao.findByShiftAndRole(shift,role);
		List<EmployeeResponseDto> list=mapper.toDtoList(elist);
		return list;
	}

}
