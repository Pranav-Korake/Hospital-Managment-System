package com.nt.service;

import java.util.List;

import com.nt.dto.PatientRequestDto;
import com.nt.dto.PatientResponseDto;

public interface PatientService {

	void add(PatientRequestDto dto);

	void update(PatientRequestDto dto);

	void deleteAll();

	void deleteById(int patientId);

	List<PatientResponseDto> selectAll();

	PatientResponseDto selectById(int patientId);

	List<PatientResponseDto> selectByName(String name);

	List<PatientResponseDto> selectByContactNumber(String contactNumber);

}
