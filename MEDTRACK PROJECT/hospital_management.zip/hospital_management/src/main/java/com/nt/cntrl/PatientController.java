package com.nt.cntrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nt.dto.PatientRequestDto;
import com.nt.dto.PatientResponseDto;
import com.nt.service.PatientService;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/patients")
public class PatientController {
	
	
	@Autowired
	private PatientService service;
	
	@PostMapping
	public ResponseEntity<String> add(@RequestBody PatientRequestDto dto)
	{
		service.add(dto);
		return ResponseEntity.status(HttpStatus.CREATED).body("added");
	}
	
	@PutMapping
	public ResponseEntity<String> update(@RequestBody PatientRequestDto dto)
	{
		service.update(dto);
		return ResponseEntity.status(HttpStatus.OK).body("updated");
	}
	
	@DeleteMapping
	public ResponseEntity<String> deleteAll()
	{
		service.deleteAll();
		return ResponseEntity.status(HttpStatus.OK).body("all deleted");
	}
	
	@DeleteMapping("/patientId/{patientId}")
	public ResponseEntity<String> deleteById(@PathVariable int patientId)
	{
		service.deleteById(patientId);
		return ResponseEntity.status(HttpStatus.OK).body("deleted");
	}
	
	@GetMapping
	public ResponseEntity<List<PatientResponseDto>> selectAll()
	{
		List<PatientResponseDto> list=service.selectAll();
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	@GetMapping("/patientId/{patientId}")
	public ResponseEntity<PatientResponseDto> selectById(@PathVariable int patientId)
	{
		PatientResponseDto dto = service.selectById(patientId);
		
		return ResponseEntity.status(HttpStatus.OK).body(dto);
	}
	

	@GetMapping("/name/{name}")
	public ResponseEntity<List<PatientResponseDto>> selectByName(@PathVariable String name)
	{
		List<PatientResponseDto> list=service.selectByName(name);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	@GetMapping("/contactNumber/{contactNumber}")
	public ResponseEntity<List<PatientResponseDto>> selectByContactNumber(@PathVariable String contactNumber)
	{
		List<PatientResponseDto> list=service.selectByContactNumber(contactNumber);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}

}
