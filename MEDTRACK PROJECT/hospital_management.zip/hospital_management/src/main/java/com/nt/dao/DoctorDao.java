package com.nt.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nt.entity.Doctor;

@Repository
public interface DoctorDao extends CrudRepository<Doctor, Integer> {

	List<Doctor> findAll();

	List<Doctor> findByName(String name);

	List<Doctor> findByQualification(String qualification);

	List<Doctor> findBySpecialization(String specialization);

	List<Doctor> findByExperience(int experience);
	
}
