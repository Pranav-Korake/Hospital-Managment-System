package com.nt.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.dao.BedDao;
import com.nt.entity.Bed;
import com.nt.entity.Bed.Status;

@Service
public class BedServiceImpl implements BedService{

	@Autowired
	private BedDao dao;

	@Override
	public List<Bed> getAllBeds() {
		List<Bed> list=dao.findAll();
		return  list;
	}

	@Override
	public List<Bed> getBedsByWard(String wardName) {
		List<Bed> list=dao.findByWardName(wardName);
		return list;
	}

	@Override
	public Bed updateBedStatus(int id, Status status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Bed bed) {
	dao.save(bed);
	}

	@Override
	public void add(Bed bed) {
       dao.save(bed);		
	}

	
	
	
}
