package com.nt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.dao.PatientDao;
import com.nt.dto.PatientRequestDto;
import com.nt.dto.PatientResponseDto;
import com.nt.entity.Patient;
import com.nt.mapper.PatientMapper;

@Service
public class PatientServiceImpl implements PatientService{
	
	@Autowired
	private PatientDao dao;
	
	@Autowired
	private PatientMapper mapper;

	@Override
	public void add(PatientRequestDto dto) {
		Patient p=mapper.toEntity(dto);
		dao.save(p);
		
	}

	@Override
	public void update(PatientRequestDto dto) {
		Patient p=mapper.toEntity(dto);
		dao.save(p);
		
	}

	@Override
	public void deleteAll() {
		dao.deleteAll();
		
	}

	@Override
	public void deleteById(int patientId) {
		dao.deleteById(patientId);
		
	}

	@Override
	public List<PatientResponseDto> selectAll() {
		List<Patient> plist=dao.findAll();
		List<PatientResponseDto> list =mapper.toDtoList(plist);
		return list;
	}

	@Override
	public PatientResponseDto selectById(int patientId) {
		Optional<Patient> opt=dao.findById(patientId);
		Patient p=opt.get();
		PatientResponseDto dto=mapper.toDto(p);
		
		
		return dto;
	}

	@Override
	public List<PatientResponseDto> selectByName(String name) {
		List<Patient> plist=dao.findByName(name);
		List<PatientResponseDto> list=mapper.toDtoList(plist);
		return list;
	}

	@Override
	public List<PatientResponseDto> selectByContactNumber(String contactNumber) {
		List<Patient> plist=dao.findBycontactNumber(contactNumber);
		List<PatientResponseDto> list=mapper.toDtoList(plist);
		return list;
	}

}
