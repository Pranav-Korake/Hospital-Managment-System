package com.nt.service;

import java.util.List;

import com.nt.dto.DoctorRequestDto;
import com.nt.dto.DoctorResponseDto;

public interface DoctorService {

	void add(DoctorRequestDto dto);

	void update(DoctorRequestDto dto);

	DoctorResponseDto selectById(int doctorId);

	List<DoctorResponseDto> selectAll();

	void deleteById(int doctorId);

	void deleteAll();

	List<DoctorResponseDto> selectByName(String name);

	List<DoctorResponseDto> selectByQualification(String qualification);

	List<DoctorResponseDto> selectBySpecialization(String specialization);

	List<DoctorResponseDto> selectByExperience(int experience);

}
