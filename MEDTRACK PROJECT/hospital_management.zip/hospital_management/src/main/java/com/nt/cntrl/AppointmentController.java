package com.nt.cntrl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nt.entity.Appointment;
import com.nt.entity.AppointmentDTO;
import com.nt.service.AppointmentService;

@RestController
@RequestMapping("/appointments")
@CrossOrigin(origins = "*")
public class AppointmentController {
	
	
	@Autowired
	private AppointmentService service;
	
	@PostMapping
	public String addAppointment(@RequestBody Appointment apt)
	{
		
		service.add(apt);
		return "added";
		
	}
	
	@PutMapping
	public String update(@RequestBody AppointmentDTO apt)
	{
		service.update(apt);
		return "updated";
	}
	
	@DeleteMapping
	public String allDelete()
	{
		service.delete();
		return "all deleted";
	}
	
	@DeleteMapping("/id/{appointment_id}")
	public String delete(@PathVariable int appointmentId)
	{
		service.delete(appointmentId);
		return "deleted";
	}
	
	@GetMapping("/id/{appointment_id}")
	public AppointmentDTO getById(@PathVariable int appointmentId)
	{
		AppointmentDTO apt=service.getById(appointmentId);
		return apt;
	}
	
	@GetMapping
	public List<Appointment> getAll()
	{
		List<Appointment> list= service.getAll();
		return list;
	}
	
	@GetMapping("/doctorName/{doctorName}")
	public List<AppointmentDTO> getAllByDoctorName(@PathVariable String doctorName)
	{
		List<AppointmentDTO> list= service.getAllByDoctorName(doctorName);
		return list;
	}
	
	  @GetMapping("/date/{date}")
	    public List<Appointment> getAppointmentsByDate(
	            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
	        return service.getByDate(date);
	    }
}
	


