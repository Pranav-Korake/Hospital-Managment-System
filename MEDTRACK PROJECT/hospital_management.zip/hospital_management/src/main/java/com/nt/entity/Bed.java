package com.nt.entity;


import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "bed")
public class Bed {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    private String wardName;

    private int bedNo;

    @Enumerated(EnumType.STRING)
    private Status status;

    public enum Status {
        EMPTY, ALLOCATED, MAINTENANCE
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getWardName() { return wardName; }
    public void setWardName(String wardName) { this.wardName = wardName; }
    public int getBedNo() { return bedNo; }
    public void setBedNo(int bedNo) { this.bedNo = bedNo; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
}
