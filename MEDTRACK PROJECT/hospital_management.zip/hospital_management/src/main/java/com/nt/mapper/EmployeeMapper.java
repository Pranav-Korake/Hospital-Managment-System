package com.nt.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nt.dto.EmployeeRequestDto;
import com.nt.dto.EmployeeResponseDto;
import com.nt.entity.Employee;

@Component
public class EmployeeMapper {
	
	
	public Employee toEntity(EmployeeRequestDto dto) {
		return new Employee(dto.getEmployeeId(),dto.getName(),dto.getGender(),dto.getDateOfBirth(),
				dto.getContactNumber(),dto.getEmail(),dto.getAddress(),dto.getRole(),dto.getJoiningDate(),
				dto.getSalary(),dto.getShift(),dto.getStatus(),dto.getEmp_photo_url());
	}
	
	
	public EmployeeResponseDto toDto(Employee e) {
		EmployeeResponseDto dto = new EmployeeResponseDto();
		dto.setEmployeeId(e.getEmployeeId());
		dto.setName(e.getName());
		dto.setGender(e.getGender());
		dto.setDateOfBirth(e.getDateOfBirth());
		dto.setContactNumber(e.getContactNumber());
		dto.setEmail(e.getEmail());
		dto.setAddress(e.getAddress());
		dto.setRole(e.getRole());
		dto.setJoiningDate(e.getJoiningDate());
		dto.setSalary(e.getSalary());
		dto.setShift(e.getShift());
		dto.setStatus(e.getStatus());
		dto.setEmp_photo_url(e.getEmp_photo_url());
		return dto;
	}
	
	public List<EmployeeResponseDto> toDtoList(List<Employee> list){
		List<EmployeeResponseDto> dtos = new ArrayList<>();
		for(Employee e : list) {
			EmployeeResponseDto dto =toDto(e);
			dtos.add(dto);
		}
		return dtos;
	}

}
