package com.nt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.dao.DoctorDao;
import com.nt.dto.DoctorRequestDto;
import com.nt.dto.DoctorResponseDto;
import com.nt.entity.Doctor;
import com.nt.mapper.DoctorMapper;

@Service
public class DoctorServiceImpl implements DoctorService {
	
	@Autowired
	private DoctorDao dao;
	
	@Autowired
	private DoctorMapper mapper;

	@Override
	public void add(DoctorRequestDto dto) {
		
		Doctor d =mapper.toEntity(dto);
		
		dao.save(d);
		
	}

	@Override
	public void update(DoctorRequestDto dto) {
		
		Doctor d = mapper.toEntity(dto);
		dao.save(d);
		
	}

	@Override
	public DoctorResponseDto selectById(int doctorId) {
		Optional<Doctor> opt=dao.findById(doctorId);
		Doctor d = opt.get();
		DoctorResponseDto dto = mapper.toDto(d);
		return dto;
		
	}

	@Override
	public List<DoctorResponseDto> selectAll() {
		
		List<Doctor> dlist = dao.findAll();
		List<DoctorResponseDto> list=mapper.toDtoList(dlist);
		return list;
	}

	@Override
	public void deleteById(int doctorId) {
		
		dao.deleteById(doctorId);
		
	}

	@Override
	public void deleteAll() {
		dao.deleteAll();
		
	}

	@Override
	public List<DoctorResponseDto> selectByName(String name) {
		
		List<Doctor> dlist=dao.findByName(name);
		List<DoctorResponseDto> list=mapper.toDtoList(dlist);
		return list;
	}

	@Override
	public List<DoctorResponseDto> selectByQualification(String qualification) {
		List<Doctor> dlist=dao.findByQualification(qualification);
		List<DoctorResponseDto> list=mapper.toDtoList(dlist);
		return list;
	}

	@Override
	public List<DoctorResponseDto> selectBySpecialization(String specialization) {
		List<Doctor> dlist=dao.findBySpecialization(specialization);
		List<DoctorResponseDto> list=mapper.toDtoList(dlist);
		return list;
	}

	@Override
	public List<DoctorResponseDto> selectByExperience(int experience) {
		List<Doctor> dlist=dao.findByExperience(experience);
		List<DoctorResponseDto> list=mapper.toDtoList(dlist);
		return list;
	}
	
	

}
