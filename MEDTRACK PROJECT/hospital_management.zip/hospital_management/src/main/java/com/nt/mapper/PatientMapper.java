package com.nt.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nt.dto.PatientRequestDto;
import com.nt.dto.PatientResponseDto;
import com.nt.entity.Patient;

@Component
public class PatientMapper {
	
	public Patient toEntity(PatientRequestDto dto) {
		return new Patient(dto.getPatientId(),dto.getName(),dto.getGender(),
				dto.getDateOfBirth(),dto.getContactNumber(),dto.getEmail(),
				dto.getAddress(),dto.getBloodGroup(),dto.getAge(),dto.getWeight(),
				dto.getEmergencyContactName(),dto.getEmergencyContactNumber(),
				dto.getPatient_photo_url());
	}
	
	
	public PatientResponseDto toDto(Patient p) {
		
		PatientResponseDto dto=new PatientResponseDto();
		dto.setPatientId(p.getPatientId());
		dto.setName(p.getName());
		dto.setGender(p.getGender());
		dto.setDateOfBirth(p.getDateOfBirth());
		dto.setContactNumber(p.getContactNumber());
		dto.setEmail(p.getEmail());
		dto.setAddress(p.getAddress());
		dto.setBloodGroup(p.getBloodGroup());
		dto.setAge(p.getAge());
		dto.setWeight(p.getWeight());
		dto.setEmergencyContactName(p.getEmergencyContactName());
		dto.setEmergencyContactNumber(p.getEmergencyContactNumber());
		dto.setPatient_photo_url(p.getPatient_photo_url());
		return dto;
		
		
	}
	
	public List<PatientResponseDto> toDtoList(List<Patient> list){
		List<PatientResponseDto> dtos = new ArrayList<>();
		for(Patient p : list) {
			PatientResponseDto dto =toDto(p);
			dtos.add(dto);
		}
		return dtos;
	}

}
