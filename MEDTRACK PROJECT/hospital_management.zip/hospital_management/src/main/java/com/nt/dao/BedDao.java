package com.nt.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nt.entity.Bed;

@Repository
public interface BedDao extends CrudRepository<Bed, Integer>
{
   
	List<Bed> findAll();

	List<Bed> findByWardNameOrderByBedNoAsc(String wardName);

	List<Bed> findByWardName(String wardName);
	
}

