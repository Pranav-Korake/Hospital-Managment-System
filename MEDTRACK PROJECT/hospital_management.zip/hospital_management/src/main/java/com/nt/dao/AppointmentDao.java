package com.nt.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nt.entity.Appointment;
import com.nt.entity.AppointmentDTO;

@Repository
public interface AppointmentDao extends CrudRepository<Appointment, Integer> {

	List<Appointment> findAll();

	List<Appointment> findByDoctorNameContainingIgnoreCase(String doctorName);

	List<Appointment> findByDate(LocalDate date);
}
