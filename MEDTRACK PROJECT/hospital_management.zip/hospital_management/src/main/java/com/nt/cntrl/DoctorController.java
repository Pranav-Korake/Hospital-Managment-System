package com.nt.cntrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nt.dto.DoctorRequestDto;
import com.nt.dto.DoctorResponseDto;
import com.nt.service.DoctorService;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/doctors")
public class DoctorController {
	
	@Autowired
	private DoctorService service;
	
	
	@PostMapping
	public ResponseEntity<String> add(@RequestBody DoctorRequestDto dto)
	{
		service.add(dto);
		return ResponseEntity.status(HttpStatus.CREATED).body("added");
	}
	
	@PutMapping
	public ResponseEntity<String> update(@RequestBody DoctorRequestDto dto)
	{
		service.update(dto);
		return ResponseEntity.status(HttpStatus.OK).body("updated");
	}
	
	@GetMapping("/doctorId/{doctorId}")
	public ResponseEntity<DoctorResponseDto> selectById(@PathVariable int doctorId)
	{
		DoctorResponseDto dto=service.selectById(doctorId);
		
		return ResponseEntity.status(HttpStatus.OK).body(dto);
		
		
	}
	
	@GetMapping
	public ResponseEntity<List<DoctorResponseDto>> selectAll()
	{
		List<DoctorResponseDto> list = service.selectAll();
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	@DeleteMapping("/doctorId/{doctorId}")
	public ResponseEntity<String> deleteById(@PathVariable int doctorId)
	{
		service.deleteById(doctorId);
		return ResponseEntity.status(HttpStatus.OK).body("deleted");
	}
	
	@DeleteMapping
	public ResponseEntity<String> deleteAll()
	{
		service.deleteAll();
		return ResponseEntity.status(HttpStatus.OK).body("all deleted");
	}
	
	@GetMapping("/name/{name}")
	public ResponseEntity<List<DoctorResponseDto>> selectByName(@PathVariable String name)
	{
		List<DoctorResponseDto> list=service.selectByName(name);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	@GetMapping("/qualification/{qualification}")
	public ResponseEntity<List<DoctorResponseDto>> selectByQualification(@PathVariable String qualification)
	{
		List<DoctorResponseDto> list=service.selectByQualification(qualification);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	@GetMapping("/specialization/{specialization}")
	public ResponseEntity<List<DoctorResponseDto>> selectBySpecialization(@PathVariable String specialization)
	{
		List<DoctorResponseDto> list=service.selectBySpecialization(specialization);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}

	@GetMapping("/experience/{experience}")
	public ResponseEntity<List<DoctorResponseDto>> selectByExperience(@PathVariable int experience)
	{
		List<DoctorResponseDto> list=service.selectByExperience(experience);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
}
