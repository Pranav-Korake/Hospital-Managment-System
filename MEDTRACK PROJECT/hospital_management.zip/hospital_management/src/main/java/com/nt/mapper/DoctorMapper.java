package com.nt.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.nt.dto.DoctorRequestDto;
import com.nt.dto.DoctorResponseDto;
import com.nt.entity.Doctor;

@Component
public class DoctorMapper {
	
	public Doctor toEntity(DoctorRequestDto dto) {
		return new Doctor(dto.getDoctorId(),dto.getName(),dto.getGender(),dto.getDateOfBirth(),
				dto.getContactNumber(),dto.getEmail(),dto.getQualification(),dto.getSpecialization(),
				dto.getExperience(),dto.getLicenseNumber(),dto.getConsultationFee(),dto.getWorkingHours()
				,dto.getAvailabilityStatus(),dto.getJoiningDate(),dto.getAddress(),dto.getPhoto_url());
	}
	
	
	public DoctorResponseDto toDto(Doctor d) {
		DoctorResponseDto dto = new DoctorResponseDto();
		dto.setDoctorId(d.getDoctorId());
		dto.setName(d.getName());
		dto.setGender(d.getGender());
		dto.setDateOfBirth(d.getDateOfBirth());
		dto.setContactNumber(d.getContactNumber());
		dto.setEmail(d.getEmail());
		dto.setQualification(d.getQualification());
		dto.setSpecialization(d.getSpecialization());
		dto.setExperience(d.getExperience());
		dto.setLicenseNumber(d.getLicenseNumber());
		dto.setConsultationFee(d.getConsultationFee());
		dto.setWorkingHours(d.getWorkingHours());
		dto.setAvailabilityStatus(d.getAvailabilityStatus());
		dto.setJoiningDate(d.getJoiningDate());
		dto.setAddress(d.getAddress());
		dto.setPhoto_url(d.getPhoto_url());
		return dto;
	}
	
	public List<DoctorResponseDto> toDtoList(List<Doctor> list){
		List<DoctorResponseDto> dtos = new ArrayList<>();
		for(Doctor d : list) {
			DoctorResponseDto dto =toDto(d);
			dtos.add(dto);
		}
		return dtos;
	}
	

}
