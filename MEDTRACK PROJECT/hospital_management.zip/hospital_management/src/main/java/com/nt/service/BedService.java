package com.nt.service;

import java.util.List;

import com.nt.entity.Bed;
import com.nt.entity.Bed.Status;

public interface BedService {

	List<Bed> getAllBeds();

	List<Bed> getBedsByWard(String wardName);

	Bed updateBedStatus(int id, Status status);

	void update(Bed bed);

	void add(Bed bed);

}