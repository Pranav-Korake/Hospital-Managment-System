package com.nt.service;

import java.time.LocalDate;
import java.util.List;

import com.nt.entity.Appointment;
import com.nt.entity.AppointmentDTO;

public interface AppointmentService {

	void add(Appointment apt);

	void update(AppointmentDTO apt);

	void delete();

	void delete(int appointmentId);

	AppointmentDTO getById(int appointmentId);

	List<Appointment> getAll();

	List<AppointmentDTO> getAllByDoctorName(String doctorName);

	List<Appointment> getAllByDate(LocalDate date);

	List<Appointment> getByDate(LocalDate date);

	

	
	
	
}
