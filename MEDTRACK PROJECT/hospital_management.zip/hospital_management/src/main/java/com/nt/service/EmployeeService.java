package com.nt.service;

import java.util.List;

import com.nt.dto.EmployeeRequestDto;
import com.nt.dto.EmployeeResponseDto;

public interface EmployeeService {

	void add(EmployeeRequestDto dto);

	void update(EmployeeRequestDto dto);

	void deleteById(int employeeId);

	void deleteAll();

	EmployeeResponseDto selectById(int employeeId);

	List<EmployeeResponseDto> selectAll();

	List<EmployeeResponseDto> selectByName(String name);

	List<EmployeeResponseDto> selectByRole(String role);

	List<EmployeeResponseDto> findByShiftAndRole(String shift, String role);

}
