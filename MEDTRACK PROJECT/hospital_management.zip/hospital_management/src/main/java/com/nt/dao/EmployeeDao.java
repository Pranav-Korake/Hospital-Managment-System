package com.nt.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nt.entity.Employee;

@Repository
public interface EmployeeDao extends CrudRepository<Employee, Integer> {
	
	List<Employee> findAll();

	List<Employee> findByName(String name);

	List<Employee> findByRole(String role);

	List<Employee> findByShiftAndRole(String shift, String role);

}
