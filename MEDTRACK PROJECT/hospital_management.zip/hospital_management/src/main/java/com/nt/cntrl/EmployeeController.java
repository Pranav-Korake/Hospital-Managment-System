package com.nt.cntrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nt.dto.EmployeeRequestDto;
import com.nt.dto.EmployeeResponseDto;
import com.nt.service.EmployeeService;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	@PostMapping
	public ResponseEntity<String> add(@RequestBody EmployeeRequestDto dto)
	{
		service.add(dto);
		return ResponseEntity.status(HttpStatus.CREATED).body("added");
	}
	
	@PutMapping
	public ResponseEntity<String> update(@RequestBody EmployeeRequestDto dto)
	{
		service.update(dto);
		return ResponseEntity.status(HttpStatus.OK).body("updated");
	}
	
	@DeleteMapping("/employeeId/{employeeId}")
	public ResponseEntity<String> deleteById(@PathVariable int employeeId)
	{
		service.deleteById(employeeId);
		return ResponseEntity.status(HttpStatus.OK).body("deleted");
	}
	
	@DeleteMapping
	public ResponseEntity<String> deleteAll()
	{
		service.deleteAll();
		return ResponseEntity.status(HttpStatus.OK).body("all deleted");
	}

	@GetMapping("/employeeId/{employeeId}")
	public ResponseEntity<EmployeeResponseDto> selectById(@PathVariable int employeeId)
	{
		EmployeeResponseDto dto=service.selectById(employeeId);
		return ResponseEntity.status(HttpStatus.OK).body(dto);
	}
	
	@GetMapping
	public ResponseEntity<List<EmployeeResponseDto>> selectAll()
	{
		List<EmployeeResponseDto> list=service.selectAll();
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	@GetMapping("/name/{name}")
	public ResponseEntity<List<EmployeeResponseDto>> selectByName(@PathVariable String name)
	{
		List<EmployeeResponseDto> list=service.selectByName(name);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	@GetMapping("/role/{role}")
	public ResponseEntity<List<EmployeeResponseDto>> selectByRole(@PathVariable String role)
	{
		List<EmployeeResponseDto> list=service.selectByRole(role);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
	
	@GetMapping("/shift/{shift}/role/{role}")
	public ResponseEntity<List<EmployeeResponseDto>> findByShiftAndRole(@PathVariable String shift,@PathVariable String role)
	{
		List<EmployeeResponseDto> list=service.findByShiftAndRole(shift,role);
		return ResponseEntity.status(HttpStatus.OK).body(list);
	}
}
