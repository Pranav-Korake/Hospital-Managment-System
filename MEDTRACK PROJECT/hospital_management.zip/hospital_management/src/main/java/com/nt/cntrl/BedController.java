package com.nt.cntrl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nt.entity.Bed;
import com.nt.service.BedService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/beds")

public class BedController {

    
	@Autowired
	private BedService service;
	
	
	@PostMapping
	public String addBed(@RequestBody Bed bed)
	{
		service.add(bed);
		return "added";
	}

  
    // Get all beds
    @GetMapping
    public List<Bed> getAllBeds() {
        return service.getAllBeds();
    }

    // Get beds by ward
    @GetMapping("/ward/{wardName}")
    public List<Bed> getBedsByWard(@PathVariable String wardName) {
        return service.getBedsByWard(wardName);
    }

   
    @PutMapping
	public String update(@RequestBody Bed bed)
	{
		service.update(bed);
		return "updated";
	}
}
